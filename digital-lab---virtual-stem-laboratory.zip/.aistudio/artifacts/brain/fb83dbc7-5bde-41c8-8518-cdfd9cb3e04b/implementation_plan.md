# Digital Lab — Technical Architecture & Implementation Blueprint

An offline-first, mobile-optimized virtual STEM laboratory and multilingual AI tutor tailored for West African secondary examinations (WAEC, NECO, JAMB) and tertiary 100-level university science curricula, designed to execute flawlessly on 2 GB RAM Android devices and patchy network conditions.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The architectural design integrates the user's specific confirmation regarding **adaptive 3D rendering with automatic device watchdog fallback**, alongside syllabus-accurate volumetric chemistry and localized multilingual tutoring.

- **Confirmed Decision 1 (Flagship Experiment & Curricula)**: Acid-Base Titration ($\text{0.100 M HCl}$ vs $\text{0.100 M NaOH}$ with Phenolphthalein indicator) will serve as the active flagship interactive laboratory, with secondary profile (WAEC Paper 3 concordant titre within $\pm 0.10\text{ mL}$) and tertiary profile (adjustable aliquots, instrument uncertainty, stoichiometric deductions). The library catalog also includes Physics (Simple Pendulum, Ohm's Law) and Biology (Qualitative Starch & Sugar Tests).
- **Confirmed Decision 2 (Multilingual Voice Tutor — LabBot)**: Default English interface with instant one-tap switching to **Nigerian Pidgin**, **Yorùbá** (with standard tonal diacritics: `ẹ`, `ọ`, `ṣ`, `à`, `é`), and **Hausa** (`ɓ`, `ɗ`, `ƙ`), featuring synthesized offline-capable audio explanations.
- **Confirmed Decision 3 (Adaptive 3D with Automatic Fallback Watchdog)**: High-fidelity procedural Three.js 3D apparatus (glass burette, stopcock, conical flask, meniscus, meniscus camera zoom, clamp stand, liquid level animation, and colorimetry gradient) equipped with an active frame-time and WebGL context watchdog. If the device drops below 20 fps, encounters a WebGL context loss, or if the user taps "2D Mode", the app instantly and seamlessly shifts to the ultra-lightweight vector Canvas 2D engine without losing student state or titre measurements.
- **Confirmed Decision 4 (Design System & Offline Readiness)**: Material Design 3 token architecture with Lexend display typography, Noto Sans body, tabular numerals (`tabular-nums`), 48×48dp non-drag discrete tap buttons, and pure client-side IndexedDB persistence for complete zero-data offline capability.

---

### 1. Overview & Core Concept

- **What It Does**: Digital Lab provides an authentic practical laboratory environment where students conduct volumetric titration experiments step-by-step: rinsing apparatus, filling the burette, setting initial readings ($0.00\text{ mL}$), adding titrant dropwise ($+0.1\text{ mL}$) or rapidly ($+1.0\text{ mL}$), swirling the flask, detecting the exact faint permanent pink endpoint ($V_B \approx 24.15\text{ mL}$), recording concordant trials in an official WAEC/tertiary tabular ledger, performing stoichiometric mole ratio calculations, taking an examiner critique quiz, and receiving dialect-specific spoken guidance.
- **Target Audience & Personas**:
  - *Secondary Students (SS1–SS3)*: Preparing for WAEC WASSCE Chemistry Paper 3 and NECO practicals on budget Android devices.
  - *Tertiary Undergraduates (100–200 Level)*: Chemistry/Engineering students needing quantitative error analysis, multi-trial concordance, and exportable lab reports.
  - *Secondary Teachers & Lecturers*: Demonstrating apparatus techniques via projectors or shared mobile screens.
- **Key Value**: Overcomes the severe 78% deficit in functional school physical labs across Nigeria, eliminating expensive reagent costs and broken glassware while raising practical exam pass rates.

---

### 2. User Experience & Visual Design

#### A. Key User Flows
1. **App Shell & Dashboard Navigation**:
   - Top Bar: Academic wordmark *Digital Lab*, level switcher (`Secondary (WAEC/NECO)` vs `Tertiary (100L)`), language selector (EN, Pidgin, Yorùbá, Hausa), and device engine status badge (`3D Active` / `2D Fallback`).
   - Home Screen: "Continue Lab" hero card displaying active progress, subject filter chips (*All*, *Chemistry*, *Physics*, *Biology*), and experiment cards with offline storage indicators.
2. **Interactive Lab Workspace**:
   - Top Stage ($60\%$ height on mobile, split-view on desktop): Interactive 3D glassware viewport with Three.js procedural materials.
   - Quick Camera Presets: Single-tap buttons for `Overview`, `Burette Zoom (Meniscus)`, and `Flask View (Color Change)`.
   - Accessible DOM Reading HUD: Live high-contrast reading overlay (`12.40 mL`) with screen reader `aria-live="polite"` feedback.
   - Collapsible Bottom Control Dock: Discrete non-drag controls:
     - `−1.0 mL` (Reset/Back step)
     - `+0.1 mL Dropwise` (Precision micro-titration near endpoint)
     - `+1.0 mL Rapid` (Fast titrant addition)
     - `Swirl Flask` (15s dissolution simulation with visual liquid agitation)
     - `Record Reading` (Pushes trial measurement into notebook)
     - `Mode Switch` (Instant toggle between Three.js 3D and 2D Canvas)
3. **Readings & Volumetric Notebook**:
   - Official 4-column trial ledger (Rough, Trial 1, Trial 2, Trial 3) with Initial, Final, and Titre volume.
   - WAEC Concordance Validator: Automatically validates concordant readings within $\le 0.10\text{ mL}$ spread and computes accurate average titre $V_B$.
   - Interactive Stoichiometry Step-by-Step Solver: Calculates $C_A$ from $\frac{C_A V_A}{C_B V_B} = \frac{n_A}{n_B}$.
   - Export affordances: Download lab sheet as CSV or printable report.
4. **Assessment & Diagnostic Critique**:
   - WAEC-aligned practical quiz cards (e.g., parallax errors, why rinse with acid, indicator selection).
   - Instant diagnostic explanations with scoring breakdown.
5. **Multilingual Voice Assistant (LabBot)**:
   - Dedicated drawer or overlay providing contextual help in English, Nigerian Pidgin ("*Abeg watch the color well-well make you no overshoot!*"), Yorùbá ("*Ẹ kiyesara ki awọ rẹ ma baa pọju!*"), and Hausa ("*Kula da kalar sosai kar ta wuce gona da iri!*").
   - Web Audio speech synthesis and dialect audio cues.

#### B. Visual Identity & Design Tokens
- **Theme Standard**: Google Material Design 3 (M3) education palette.
  - Primary Canvas: `#FBF8FF` (Light) / `#121316` (Dark) with subtle CSS graph-paper grid.
  - Primary Academic Blue: `#1F5FBF` (onPrimary `#FFFFFF`, Container `#D8E6FF`).
  - Lab Science Teal: `#00696B` (Container `#BDEBEC`).
  - Warm Achievement Amber: `#7A5900` (Container `#FFDF9E`).
  - Endpoint Pink Colorimetry: Smooth CSS/Shader transition from water clear `#F0F4F8` $\to$ pale permanent pink `#FCE7F3` ($V \ge 24.10\text{ mL}$) $\to$ deep overtitrated magenta `#BE185D` ($V > 24.30\text{ mL}$).
- **Typography**: Lexend for Display/Headings; Noto Sans for Body; tabular monospace (`tabular-nums`) for burette values and ledger math.
- **Accessibility & Ergonomics**:
  - Touch targets $\ge 48\times 48\text{dp}$ with $\ge 8\text{dp}$ spacing buffers.
  - Never convey chemical changes by color alone: always paired with state tags (`Acidic: Clear`, `Neutral Endpoint: Pale Pink`, `Alkaline Overshot: Magenta`).
  - Fully compliant with WCAG 2.2 AA contrast ratios.

---

### 3. Key Product Decisions & Trade-Offs

#### Decision 1: Hybrid Dual-Engine Simulation (Three.js 3D + 2D HTML5 Canvas Fallback)
- **Chosen Approach**: Build a unified simulation state engine (`TitrationSimulation`) decoupled from rendering. The primary renderer uses Three.js r160+ with procedural low-poly geometry (lathed flasks, extruded stands, cylinder burette with tick marks, dynamic liquid shaders, and room environment). Alongside this, build a dedicated 2D HTML5 Canvas renderer that draws the identical apparatus. An active runtime FPS and WebGL context watchdog automatically downgrades to 2D if performance stalls or WebGL context crashes, with a manual override toggle.
- **Why**: Many public school Android phones in West Africa are equipped with Unisoc or MediaTek entry-level chipsets with aggressive thermal throttling. This architecture guarantees zero crashes.
- **Alternatives Considered**: Three.js only (risks out-of-memory crashes on 2 GB RAM phones); 2D only (lacks spatial engagement and apparatus realism).

#### Decision 2: Pure Procedural Zero-Asset Pipeline
- **Chosen Approach**: Zero external `.glb`, `.obj`, or heavy texture files. All glassware, stands, liquids, and meniscus markings are procedurally generated in TypeScript using `LatheGeometry`, `CylinderGeometry`, `CanvasTexture`, and CSS overlays.
- **Why**: Keeps the initial load under $700\text{ KB}$, loads instantly in offline environments, and uses negligible RAM.

#### Decision 3: Offline-First Client Architecture with IndexedDB
- **Chosen Approach**: Store student trials, custom parameter adjustments, quiz completions, and offline laboratory packages in local IndexedDB with a Service Worker caching the application shell.
- **Why**: Satisfies the core requirement of complete zero-data usage after the first web visit in high-data-cost regions.

---

### 4. Technical Architecture & Data Strategy

#### System & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           DIGITAL LAB CLIENT APPLICATION                        │
│                                                                                 │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │ TopBar: Wordmark · Level (Secondary/Tertiary) · Language · Engine Badge │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │ Active View Router: [Dashboard] · [Lab Workspace] · [Ledger] · [Quiz]   │   │
│   └────────────────────────────────────┬────────────────────────────────────┘   │
│                                        │                                        │
│               ┌────────────────────────┴────────────────────────┐               │
│               ▼                                                 ▼               │
│   ┌───────────────────────────┐                     ┌───────────────────────┐   │
│   │    SIMULATION ENGINE      │                     │   MULTILINGUAL BOT    │   │
│   │  - Fixed delta timestep   │                     │  - Dialect Switcher   │   │
│   │  - Stoichiometry math     │                     │    (EN/Pidgin/YO/HA)  │   │
│   │  - pH & Color calculation │                     │  - Voice synthesis    │   │
│   │  - WAEC concordance rules │                     │  - Parallax camera OCR│   │
│   └─────────────┬─────────────┘                     └───────────────────────┘   │
│                 │ (State updates)                                               │
│        ┌────────┴───────────────────────────┐                                   │
│        ▼                                    ▼                                   │
│   ┌───────────────────────────┐   ┌─────────────────────────┐                   │
│   │  Three.js 3D Viewport     │   │  2D Canvas Fallback     │                   │
│   │  - Lathed Flask & Burette │   │  - Vector apparatus     │                   │
│   │  - Procedural liquid      │   │  - Direct 2D context    │                   │
│   │  - Camera presets         │   │  - Zero GPU overhead    │                   │
│   │  - Idle render pause      │   │  - Crisp high-DPI scale │                   │
│   └─────────────┬─────────────┘   └────────────┬────────────┘                   │
│                 │                              │                                │
│                 └──────────────┬───────────────┘                                │
│                                ▼                                                │
│                 ┌─────────────────────────────┐                                 │
│                 │   Render Watchdog / Toggle  │                                 │
│                 │   - Auto-downgrades < 20fps │                                 │
│                 │   - WebGL context recovery  │                                 │
│                 └─────────────────────────────┘                                 │
│                                │                                                │
│                                ▼                                                │
│                 ┌─────────────────────────────┐                                 │
│                 │    INDEXEDDB LOCAL STORE    │                                 │
│                 │  - Student trials & readings│                                 │
│                 │  - Calculated titre averages│                                 │
│                 │  - Quiz scores & notes      │                                 │
│                 └─────────────────────────────┘                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

#### Core Data Models & State Types
```typescript
export type AcademicLevel = 'secondary' | 'tertiary';
export type SupportedLanguage = 'en' | 'pcm' | 'yo' | 'ha'; // English, Pidgin, Yoruba, Hausa
export type IndicatorType = 'phenolphthalein' | 'methyl_orange';

export interface TitrationState {
  buretteCapacity: number;     // 50.00 mL
  currentBuretteVolume: number;// 0.00 to 50.00 mL
  dispensedVolume: number;     // e.g. 24.15 mL
  flaskInitialVolume: number;  // 25.00 mL aliquot
  acidConcentration: number;   // 0.100 M HCl
  baseConcentration: number;   // 0.100 M NaOH
  indicator: IndicatorType;
  endpointVolume: number;      // 24.15 mL (calculated theoretical)
  isSwirling: boolean;
  colorHex: string;
  colorLabel: string;
  chemicalState: 'acidic' | 'neutral_endpoint' | 'overshot';
}

export interface TitrationTrial {
  id: string;
  trialNumber: number; // 0 for Rough, 1, 2, 3
  isRough: boolean;
  initialReading: number;
  finalReading: number;
  titre: number;
  isConcordant?: boolean;
}

export interface LabCalculation {
  meanTitre: number;
  concordantTrials: number[];
  acidMolarity: number;
  baseMolarity: number;
  formula: string;
  isCorrect: boolean;
}
```

#### Interactive Component Mapping
- `App.tsx`: Main state coordinator (active tab, academic level, active language, notification toast).
- `TopAppBar.tsx`: Sticky M3 header with three zones: Brand, Level & Language selectors, and Render Engine indicator/toggle.
- `DashboardView.tsx`: Overview of practical modules, resume card, storage manager, and curriculum syllabus tags (WAEC/NECO/100L).
- `LabWorkspaceView.tsx`: Houses the 3D/2D apparatus viewport, reading overlay, camera presets, and collapsible bottom action dock.
- `ThreeJsLabViewport.tsx`: Procedural Three.js scene with custom glassware, meniscus shader, stopcock rotation, liquid mesh, and idle render loop.
- `Canvas2DLabViewport.tsx`: Fallback vector apparatus rendered with crisp 2D canvas drawing paths, ensuring seamless visual continuity.
- `RenderWatchdog.ts`: Monitors frame render time and WebGL context stability, automatically switching between 3D and 2D.
- `ReadingsNotebookView.tsx`: Tabular ledger with WAEC concordance calculations and stoichiometry solver.
- `AssessmentQuizView.tsx`: Multi-question formative assessment with diagnostic feedback and grading rubric.
- `LabBotDrawer.tsx`: Dialect assistant with English, Pidgin, Yorùbá, and Hausa explanations plus audio synthesis.
- `storageService.ts`: Pure IndexedDB wrapper for trial storage and offline caching.
