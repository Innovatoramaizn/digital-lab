/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LiveVoiceCallbacks {
  onStatusChange: (status: 'disconnected' | 'connecting' | 'connected' | 'speaking' | 'listening') => void;
  onError: (error: string) => void;
  onTranscriptChunk?: (text: string) => void;
}

export class LiveAudioClient {
  private ws: WebSocket | null = null;
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private callbacks: LiveVoiceCallbacks;
  private isConnected = false;
  private isMuted = false;
  private scheduledTime = 0;
  private activeSources: AudioBufferSourceNode[] = [];

  constructor(callbacks: LiveVoiceCallbacks) {
    this.callbacks = callbacks;
  }

  public async connect(): Promise<void> {
    if (this.isConnected) return;
    this.callbacks.onStatusChange('connecting');

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live`;
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = async () => {
        this.isConnected = true;
        this.callbacks.onStatusChange('connected');
        await this.startMicrophone();
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.error) {
            this.callbacks.onError(msg.error);
            return;
          }

          if (msg.interrupted) {
            this.stopAllAudio();
            this.callbacks.onStatusChange('listening');
            return;
          }

          if (msg.text && this.callbacks.onTranscriptChunk) {
            this.callbacks.onTranscriptChunk(msg.text);
          }

          if (msg.audio) {
            this.playPcmChunk(msg.audio);
          }
        } catch (err) {
          console.warn('Error parsing Live API message:', err);
        }
      };

      this.ws.onclose = () => {
        this.cleanup();
        this.callbacks.onStatusChange('disconnected');
      };

      this.ws.onerror = (err) => {
        console.error('Live API WebSocket error:', err);
        this.callbacks.onError('Live API WebSocket connection error');
        this.cleanup();
      };
    } catch (err: any) {
      this.callbacks.onError(err?.message || 'Failed to connect to Live Voice API');
      this.callbacks.onStatusChange('disconnected');
    }
  }

  private async startMicrophone(): Promise<void> {
    try {
      // 16kHz audio context for input to Gemini Live
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.inputAudioCtx = new AudioCtx({ sampleRate: 16000 });
      this.outputAudioCtx = new AudioCtx({ sampleRate: 24000 });

      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
        },
      });

      const source = this.inputAudioCtx.createMediaStreamSource(this.mediaStream);
      this.processor = this.inputAudioCtx.createScriptProcessor(2048, 1, 1);

      this.processor.onaudioprocess = (e) => {
        if (!this.isConnected || !this.ws || this.ws.readyState !== WebSocket.OPEN || this.isMuted) {
          return;
        }

        const inputData = e.inputBuffer.getChannelData(0);
        // Convert Float32 to 16-bit PCM Little Endian
        const base64Pcm = this.floatTo16BitPcmBase64(inputData);
        this.ws.send(JSON.stringify({ audio: base64Pcm }));
      };

      source.connect(this.processor);
      this.processor.connect(this.inputAudioCtx.destination);
      this.callbacks.onStatusChange('listening');
    } catch (err: any) {
      console.error('Microphone access error:', err);
      this.callbacks.onError(err?.message || 'Microphone access denied or unavailable');
    }
  }

  private floatTo16BitPcmBase64(input: Float32Array): string {
    const buffer = new ArrayBuffer(input.length * 2);
    const view = new DataView(buffer);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }

    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private playPcmChunk(base64Audio: string): void {
    if (!this.outputAudioCtx) return;

    try {
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert 16-bit PCM to Float32
      const dataView = new DataView(bytes.buffer);
      const sampleCount = len / 2;
      const float32Data = new Float32Array(sampleCount);
      for (let i = 0; i < sampleCount; i++) {
        const int16 = dataView.getInt16(i * 2, true);
        float32Data[i] = int16 / 32768.0;
      }

      const audioBuffer = this.outputAudioCtx.createBuffer(1, sampleCount, 24000);
      audioBuffer.copyToChannel(float32Data, 0);

      const sourceNode = this.outputAudioCtx.createBufferSource();
      sourceNode.buffer = audioBuffer;
      sourceNode.connect(this.outputAudioCtx.destination);

      const currentTime = this.outputAudioCtx.currentTime;
      if (this.scheduledTime < currentTime) {
        this.scheduledTime = currentTime;
      }

      sourceNode.start(this.scheduledTime);
      this.scheduledTime += audioBuffer.duration;
      this.activeSources.push(sourceNode);

      this.callbacks.onStatusChange('speaking');

      sourceNode.onended = () => {
        const index = this.activeSources.indexOf(sourceNode);
        if (index > -1) this.activeSources.splice(index, 1);
        if (this.activeSources.length === 0) {
          this.callbacks.onStatusChange('listening');
        }
      };
    } catch (err) {
      console.warn('Error playing audio chunk:', err);
    }
  }

  private stopAllAudio(): void {
    for (const source of this.activeSources) {
      try {
        source.stop();
      } catch {
        // ignore
      }
    }
    this.activeSources = [];
    if (this.outputAudioCtx) {
      this.scheduledTime = this.outputAudioCtx.currentTime;
    }
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
  }

  public disconnect(): void {
    this.cleanup();
    this.callbacks.onStatusChange('disconnected');
  }

  private cleanup(): void {
    this.isConnected = false;
    this.stopAllAudio();

    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.inputAudioCtx) {
      this.inputAudioCtx.close();
      this.inputAudioCtx = null;
    }

    if (this.outputAudioCtx) {
      this.outputAudioCtx.close();
      this.outputAudioCtx = null;
    }

    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }
  }
}
