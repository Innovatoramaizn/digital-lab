/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { IndicatorType, TitrationState, TitrationTrial } from '../types/lab.ts';

export const THEORETICAL_ENDPOINT = 24.15; // mL for standard WAEC 0.100 M HCl vs NaOH
export const INITIAL_BURETTE_MAX = 50.00; // mL
export const ALIQUOT_VOLUME = 25.00; // mL

export class TitrationEngine {
  private state: TitrationState;

  constructor(endpoint: number = THEORETICAL_ENDPOINT) {
    this.state = this.getInitialState(endpoint);
  }

  public getInitialState(endpoint: number = THEORETICAL_ENDPOINT): TitrationState {
    return {
      buretteCapacity: INITIAL_BURETTE_MAX,
      currentBuretteVolume: 0.00, // 0.00 mL at the top line
      dispensedVolume: 0.00,
      aliquotVolume: ALIQUOT_VOLUME,
      acidConcentration: 0.100, // mol/dm^3
      baseConcentration: 0.0966, // mol/dm^3
      indicator: 'phenolphthalein',
      endpointVolume: endpoint,
      isSwirling: false,
      swirlProgress: 0,
      colorHex: '#F0F4F8',
      colorLabel: 'Clear (Acidic)',
      chemicalState: 'acidic',
      pH: 1.5,
      lastAddedDelta: 0,
    };
  }

  public getState(): TitrationState {
    return { ...this.state };
  }

  public setIndicator(indicator: IndicatorType): TitrationState {
    this.state.indicator = indicator;
    this.updateChemicalState();
    return this.getState();
  }

  public setTertiaryParams(acidConc: number, baseConc: number, aliquot: number): TitrationState {
    this.state.acidConcentration = acidConc;
    this.state.baseConcentration = baseConc;
    this.state.aliquotVolume = aliquot;
    // Calculate new theoretical endpoint: V_A = (C_B * V_B) / C_A
    const calculatedEndpoint = (baseConc * aliquot) / acidConc;
    this.state.endpointVolume = Number(calculatedEndpoint.toFixed(2));
    this.updateChemicalState();
    return this.getState();
  }

  public dispense(deltaMl: number): TitrationState {
    const newDispensed = Math.min(
      this.state.buretteCapacity,
      Math.max(0, Number((this.state.dispensedVolume + deltaMl).toFixed(2)))
    );
    this.state.dispensedVolume = newDispensed;
    this.state.currentBuretteVolume = newDispensed;
    this.state.lastAddedDelta = deltaMl;
    this.updateChemicalState();
    return this.getState();
  }

  public stepBack(deltaMl: number = 1.0): TitrationState {
    return this.dispense(-deltaMl);
  }

  public refillBurette(): TitrationState {
    this.state.currentBuretteVolume = 0.00;
    this.state.dispensedVolume = 0.00;
    this.state.lastAddedDelta = 0;
    this.updateChemicalState();
    return this.getState();
  }

  public resetFlask(): TitrationState {
    this.state.dispensedVolume = 0.00;
    this.state.currentBuretteVolume = 0.00;
    this.state.lastAddedDelta = 0;
    this.updateChemicalState();
    return this.getState();
  }

  public setSwirling(isSwirling: boolean): TitrationState {
    this.state.isSwirling = isSwirling;
    return this.getState();
  }

  private updateChemicalState(): void {
    const v = this.state.dispensedVolume;
    const ep = this.state.endpointVolume;
    const diff = v - ep;

    if (this.state.indicator === 'phenolphthalein') {
      if (diff < -0.15) {
        // Significantly below endpoint: acidic/clear
        this.state.chemicalState = 'acidic';
        this.state.colorHex = '#F0F4F8';
        this.state.colorLabel = 'Colorless (Acidic)';
        this.state.pH = Math.max(1.5, Number((3.5 - (ep - v) * 0.1).toFixed(2)));
      } else if (Math.abs(diff) <= 0.15) {
        // Within +- 0.15 mL of endpoint: faint permanent pink (Concordant WAEC Endpoint!)
        this.state.chemicalState = 'neutral_endpoint';
        this.state.colorHex = '#FCE7F3'; // Faint delicate pink
        this.state.colorLabel = 'Faint Permanent Pink (Endpoint Reached!)';
        this.state.pH = 7.0;
      } else {
        // Overshot (> +0.15 mL)
        this.state.chemicalState = 'overshot';
        if (diff < 1.0) {
          this.state.colorHex = '#F472B6'; // Rose pink
          this.state.colorLabel = 'Bright Pink (Slightly Overshot)';
          this.state.pH = 8.8;
        } else {
          this.state.colorHex = '#BE185D'; // Deep magenta
          this.state.colorLabel = 'Deep Magenta (Overtitrated)';
          this.state.pH = Math.min(13.0, Number((9.5 + diff * 0.2).toFixed(2)));
        }
      }
    } else {
      // Methyl Orange indicator (Red in acid, Orange at endpoint, Yellow in base)
      if (diff < -0.15) {
        this.state.chemicalState = 'acidic';
        this.state.colorHex = '#EF4444'; // Red
        this.state.colorLabel = 'Red (Acidic)';
        this.state.pH = 3.1;
      } else if (Math.abs(diff) <= 0.15) {
        this.state.chemicalState = 'neutral_endpoint';
        this.state.colorHex = '#F97316'; // Orange
        this.state.colorLabel = 'Orange (Neutral Endpoint)';
        this.state.pH = 4.4;
      } else {
        this.state.chemicalState = 'overshot';
        this.state.colorHex = '#EAB308'; // Yellow
        this.state.colorLabel = 'Yellow (Alkaline Overshot)';
        this.state.pH = 9.0;
      }
    }
  }

  /**
   * WAEC Concordance Calculation Engine
   * Rules according to WAEC Chemistry Paper 3:
   * 1. Rough trial is recorded but never included in average titre.
   * 2. Two or three trials are concordant if the difference between highest and lowest is <= 0.10 mL (or 0.20 max in some lenient bands, but strictly <= 0.10 mL for full marks).
   */
  public static evaluateConcordance(trials: TitrationTrial[]): {
    concordantIndices: number[];
    averageTitre: number | null;
    isConcordant: boolean;
    feedbackMessage: string;
  } {
    // Exclude rough trial
    const validTrials = trials.filter((t) => !t.isRough);

    if (validTrials.length < 2) {
      return {
        concordantIndices: [],
        averageTitre: null,
        isConcordant: false,
        feedbackMessage: 'Complete at least 2 non-rough trials to calculate concordance.',
      };
    }

    // Check pairs or triplets
    let bestSet: TitrationTrial[] = [];
    let minSpread = Infinity;

    // Check all combinations of 2 or 3 trials
    for (let i = 0; i < validTrials.length; i++) {
      for (let j = i + 1; j < validTrials.length; j++) {
        const pair = [validTrials[i], validTrials[j]];
        const spread = Math.abs(pair[0].titre - pair[1].titre);
        if (spread < minSpread) {
          minSpread = spread;
          bestSet = pair;
        }

        // Try triplet if 3 or more available
        for (let k = j + 1; k < validTrials.length; k++) {
          const triplet = [validTrials[i], validTrials[j], validTrials[k]];
          const maxT = Math.max(...triplet.map((t) => t.titre));
          const minT = Math.min(...triplet.map((t) => t.titre));
          const tripSpread = maxT - minT;
          if (tripSpread < minSpread) {
            minSpread = tripSpread;
            bestSet = triplet;
          }
        }
      }
    }

    const isConcordant = minSpread <= 0.10;
    const avg = Number(
      (bestSet.reduce((sum, t) => sum + t.titre, 0) / bestSet.length).toFixed(2)
    );

    const concordantIds = bestSet.map((t) => t.trialNumber);

    let msg = '';
    if (isConcordant) {
      msg = `Excellent! Trials ${concordantIds.join(' and ')} are concordant with a spread of ${minSpread.toFixed(2)} mL (≤ 0.10 mL). Average Titre = ${avg.toFixed(2)} mL.`;
    } else {
      msg = `Spread between closest trials is ${minSpread.toFixed(2)} mL. In WAEC, concordant trials must agree within ±0.10 mL. Conduct another trial carefully.`;
    }

    return {
      concordantIndices: concordantIds,
      averageTitre: avg,
      isConcordant,
      feedbackMessage: msg,
    };
  }

  /**
   * Stoichiometric calculation:
   * (C_A * V_A) / (C_B * V_B) = n_A / n_B
   * => C_A = (C_B * V_B * n_A) / (V_A * n_B)
   */
  public static calculateAcidConcentration(
    baseMolarity: number,
    meanTitreBase: number,
    acidAliquot: number = 25.0,
    ratioAcid: number = 1,
    ratioBase: number = 1
  ): number {
    return Number(((baseMolarity * meanTitreBase * ratioAcid) / (acidAliquot * ratioBase)).toFixed(4));
  }
}
