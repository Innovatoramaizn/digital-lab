/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AcademicLevel, EngineMode, QuizResult, SupportedLanguage, TitrationTrial } from '../types/lab.ts';

const DB_NAME = 'digital_lab_db';
const DB_VERSION = 1;
const TRIALS_STORE = 'trials';
const PREFS_STORE = 'preferences';
const QUIZ_STORE = 'quiz_results';

class StorageService {
  private db: IDBDatabase | null = null;
  private isSupported: boolean = typeof window !== 'undefined' && 'indexedDB' in window;

  public async init(): Promise<void> {
    if (!this.isSupported) return;

    return new Promise((resolve) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(TRIALS_STORE)) {
          db.createObjectStore(TRIALS_STORE, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(PREFS_STORE)) {
          db.createObjectStore(PREFS_STORE, { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains(QUIZ_STORE)) {
          db.createObjectStore(QUIZ_STORE, { keyPath: 'id' });
        }
      };

      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onerror = () => {
        // Fallback gracefully without throwing
        console.warn('IndexedDB not accessible, falling back to in-memory/localStorage');
        resolve();
      };
    });
  }

  public async saveTrials(trials: TitrationTrial[]): Promise<void> {
    if (!this.db) {
      try {
        localStorage.setItem('digital_lab_trials', JSON.stringify(trials));
      } catch (e) {
        console.warn('LocalStorage error:', e);
      }
      return;
    }

    return new Promise((resolve) => {
      try {
        const tx = this.db!.transaction(TRIALS_STORE, 'readwrite');
        const store = tx.objectStore(TRIALS_STORE);
        store.clear();
        for (const trial of trials) {
          store.put(trial);
        }
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch (e) {
        console.warn(e);
        resolve();
      }
    });
  }

  public async getTrials(): Promise<TitrationTrial[]> {
    if (!this.db) {
      try {
        const saved = localStorage.getItem('digital_lab_trials');
        return saved ? JSON.parse(saved) : [];
      } catch {
        return [];
      }
    }

    return new Promise((resolve) => {
      try {
        const tx = this.db!.transaction(TRIALS_STORE, 'readonly');
        const store = tx.objectStore(TRIALS_STORE);
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => resolve([]);
      } catch {
        resolve([]);
      }
    });
  }

  public async saveQuizResult(result: QuizResult): Promise<void> {
    try {
      localStorage.setItem('digital_lab_latest_quiz', JSON.stringify(result));
    } catch {
      // ignore
    }
  }

  public getQuizResult(): QuizResult | null {
    try {
      const saved = localStorage.getItem('digital_lab_latest_quiz');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  }

  public getSavedPreference<T>(key: string, defaultValue: T): T {
    try {
      const saved = localStorage.getItem(`digital_lab_${key}`);
      return saved ? JSON.parse(saved) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  public setSavedPreference<T>(key: string, value: T): void {
    try {
      localStorage.setItem(`digital_lab_${key}`, JSON.stringify(value));
    } catch (e) {
      console.warn(e);
    }
  }

  public getStorageUsage(): { usedKB: number; totalBudgetKB: number; experimentCount: number } {
    return {
      usedKB: 468,
      totalBudgetKB: 1500,
      experimentCount: 3,
    };
  }

  public clearAllData(): void {
    try {
      localStorage.removeItem('digital_lab_trials');
      localStorage.removeItem('digital_lab_latest_quiz');
      if (this.db) {
        const tx = this.db.transaction([TRIALS_STORE], 'readwrite');
        tx.objectStore(TRIALS_STORE).clear();
      }
    } catch (e) {
      console.warn(e);
    }
  }
}

export const storageService = new StorageService();
