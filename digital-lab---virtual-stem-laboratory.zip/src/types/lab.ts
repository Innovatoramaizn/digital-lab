/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AcademicLevel = 'secondary' | 'tertiary';

export type SupportedLanguage = 'en' | 'pcm' | 'yo' | 'ha'; // English, Pidgin, Yoruba, Hausa

export type IndicatorType = 'phenolphthalein' | 'methyl_orange';

export type EngineMode = '3d' | '2d';

export interface TitrationState {
  buretteCapacity: number;     // e.g. 50.00 mL
  currentBuretteVolume: number;// liquid level 0.00 to 50.00 mL
  dispensedVolume: number;     // e.g. 24.15 mL
  aliquotVolume: number;       // base in flask, e.g. 25.00 mL
  acidConcentration: number;   // e.g. 0.100 mol dm^-3 HCl
  baseConcentration: number;   // e.g. 0.100 mol dm^-3 NaOH
  indicator: IndicatorType;
  endpointVolume: number;      // Theoretical endpoint e.g. 24.15 mL
  isSwirling: boolean;
  swirlProgress: number;       // 0 to 1
  colorHex: string;
  colorLabel: string;
  chemicalState: 'acidic' | 'neutral_endpoint' | 'overshot';
  pH: number;
  lastAddedDelta: number;
}

export interface TitrationTrial {
  id: string;
  trialNumber: number; // 0 for Rough, 1 for 1st, 2 for 2nd, 3 for 3rd
  label: string;
  isRough: boolean;
  initialReading: number;
  finalReading: number;
  titre: number;
  isConcordant?: boolean;
  timestamp: number;
}

export interface LabCalculation {
  meanTitre: number;
  concordantTrialIndices: number[];
  acidMolarity: number;
  baseMolarity: number;
  moleRatioAcid: number; // 1
  moleRatioBase: number; // 1
  userAnswerMolarity?: number;
  isCorrect?: boolean;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  waecTip: string;
}

export interface QuizResult {
  score: number;
  total: number;
  completedAt: number;
  answers: Record<string, number>;
}

export interface ExperimentManifest {
  id: string;
  title: string;
  subject: 'chemistry' | 'physics' | 'biology';
  paper: string;
  levels: AcademicLevel[];
  curriculumTags: string[];
  durationMinutes: number;
  assetBudgetKB: number;
  description: string;
  apparatusList: string[];
  isAvailable: boolean;
}
