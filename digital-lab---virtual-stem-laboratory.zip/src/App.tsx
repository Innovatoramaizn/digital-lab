/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { AcademicLevel, EngineMode, QuizResult, SupportedLanguage, TitrationState, TitrationTrial } from './types/lab.ts';
import { TitrationEngine } from './services/titrationEngine.ts';
import { storageService } from './services/storageService.ts';
import { audioSpeechService } from './services/audioSpeechService.ts';
import { TopAppBar } from './components/TopAppBar.tsx';
import { ThreeJsLabViewport } from './components/ThreeJsLabViewport.tsx';
import { Canvas2DLabViewport } from './components/Canvas2DLabViewport.tsx';
import { CollapsibleBottomDock } from './components/CollapsibleBottomDock.tsx';
import { ReadingsNotebookView } from './components/ReadingsNotebookView.tsx';
import { AssessmentQuizView } from './components/AssessmentQuizView.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { OhmsLawWorkspace } from './components/OhmsLawWorkspace.tsx';
import { MultilingualAssistantModal } from './components/MultilingualAssistantModal.tsx';
import { LiveVoiceFloatingBar } from './components/LiveVoiceFloatingBar.tsx';
import { AudioTranscribeModal } from './components/AudioTranscribeModal.tsx';
import { HelpCircle, Info, Mic, PhoneCall, Sparkles } from 'lucide-react';

export default function App() {
  // Navigation & Preferences State
  const [activeTab, setActiveTab] = useState<'workspace' | 'ledger' | 'quiz' | 'library'>('workspace');
  const [level, setLevel] = useState<AcademicLevel>('secondary');
  const [language, setLanguage] = useState<SupportedLanguage>('en');
  const [engineMode, setEngineMode] = useState<EngineMode>('3d');
  const [activeExperimentId, setActiveExperimentId] = useState<string>('titration-acid-base');
  const [cameraPreset, setCameraPreset] = useState<'overview' | 'burette' | 'flask'>('overview');
  const [isLabBotOpen, setIsLabBotOpen] = useState<boolean>(false);
  const [isLiveVoiceOpen, setIsLiveVoiceOpen] = useState<boolean>(false);
  const [isTranscribeOpen, setIsTranscribeOpen] = useState<boolean>(false);
  const [injectedPrompt, setInjectedPrompt] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Simulation State
  const [titrationEngine] = useState<TitrationEngine>(() => new TitrationEngine());
  const [simState, setSimState] = useState<TitrationState>(() => titrationEngine.getState());

  // Notebook Trials & Quiz State
  const [trials, setTrials] = useState<TitrationTrial[]>([]);
  const [savedQuizResult, setSavedQuizResult] = useState<QuizResult | null>(null);

  // Initialize storage on mount
  useEffect(() => {
    storageService.init().then(async () => {
      const loadedTrials = await storageService.getTrials();
      setTrials(loadedTrials);
      const loadedQuiz = storageService.getQuizResult();
      setSavedQuizResult(loadedQuiz);
      const savedLevel = storageService.getSavedPreference<AcademicLevel>('level', 'secondary');
      setLevel(savedLevel);
      const savedLang = storageService.getSavedPreference<SupportedLanguage>('language', 'en');
      setLanguage(savedLang);
      const savedEngine = storageService.getSavedPreference<EngineMode>('engine', '3d');
      setEngineMode(savedEngine);
    });
  }, []);

  const handleAddTrial = (trial: TitrationTrial) => {
    const updated = [...trials, trial];
    setTrials(updated);
    storageService.saveTrials(updated);
    showToast(`Recorded ${trial.label} (${trial.titre.toFixed(2)} mL) to notebook`);
  };

  const handleDeleteTrial = (id: string) => {
    const updated = trials.filter((t) => t.id !== id);
    setTrials(updated);
    storageService.saveTrials(updated);
  };

  const handleClearTrials = () => {
    setTrials([]);
    storageService.saveTrials([]);
    showToast('Ledger trials cleared');
  };

  const handleSaveQuizResult = (result: QuizResult) => {
    setSavedQuizResult(result);
    storageService.saveQuizResult(result);
    audioSpeechService.playEndpointChime();
    showToast(`Quiz completed: Score ${result.score}/${result.total}`);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 3500);
  };

  // Interactive Titration Handlers
  const handleDispense = (amount: number) => {
    const prevEndpoint = simState.chemicalState;
    const newState = titrationEngine.dispense(amount);
    setSimState(newState);
    audioSpeechService.playDropSound();

    if (prevEndpoint !== 'neutral_endpoint' && newState.chemicalState === 'neutral_endpoint') {
      audioSpeechService.playEndpointChime();
      showToast('Endpoint reached! Faint permanent pink observed.');
    } else if (prevEndpoint !== 'overshot' && newState.chemicalState === 'overshot') {
      audioSpeechService.playOvershootBuzz();
      showToast('Overtitrated! Liquid has turned deep magenta.');
    }
  };

  const handleStepBack = () => {
    const newState = titrationEngine.stepBack(1.0);
    setSimState(newState);
    showToast('Stepped back 1.0 mL titrant');
  };

  const handleSwirl = () => {
    const newState = titrationEngine.setSwirling(true);
    setSimState(newState);
    audioSpeechService.playSwirlSound();

    setTimeout(() => {
      const stoppedState = titrationEngine.setSwirling(false);
      setSimState(stoppedState);
    }, 1800);
  };

  const handleRefillBurette = () => {
    const newState = titrationEngine.refillBurette();
    setSimState(newState);
    showToast('Burette refilled to 0.00 mL mark');
  };

  const handleResetFlask = () => {
    const newState = titrationEngine.resetFlask();
    setSimState(newState);
    showToast('Flask emptied and fresh 25.0 mL aliquot added');
  };

  const handleRecordCurrentReading = () => {
    const finalVal = simState.dispensedVolume;
    const trialNum = trials.length === 0 ? 0 : trials.length;
    const isRough = trialNum === 0;

    const newTrial: TitrationTrial = {
      id: `trial_${Date.now()}`,
      trialNumber: trialNum,
      label: isRough ? 'Rough Trial' : `Trial ${trialNum}`,
      isRough,
      initialReading: 0.0,
      finalReading: finalVal,
      titre: finalVal,
      timestamp: Date.now(),
    };

    handleAddTrial(newTrial);
  };

  const handleFallbackTo2D = () => {
    setEngineMode('2d');
    storageService.setSavedPreference('engine', '2d');
    showToast('Switched to 2D vector apparatus (low-power mode)');
  };

  const handleToggleEngine = () => {
    const nextMode: EngineMode = engineMode === '3d' ? '2d' : '3d';
    setEngineMode(nextMode);
    storageService.setSavedPreference('engine', nextMode);
    showToast(nextMode === '3d' ? '3D WebGL mode enabled' : '2D Vector canvas mode enabled');
  };

  const handleLaunchExperiment = (id: string) => {
    setActiveExperimentId(id);
    setActiveTab('workspace');
  };

  const handleTranscriptComplete = (transcript: string) => {
    setInjectedPrompt(transcript);
    setIsLabBotOpen(true);
    showToast('Audio transcribed! Review with LabBot AI tutor.');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FBF8FF] text-[#1B1B1F] relative">
      
      {/* Top Navigation Bar */}
      <TopAppBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        level={level}
        setLevel={(l) => {
          setLevel(l);
          storageService.setSavedPreference('level', l);
        }}
        language={language}
        setLanguage={(lang) => {
          setLanguage(lang);
          storageService.setSavedPreference('language', lang);
        }}
        engineMode={engineMode}
        toggleEngineMode={handleToggleEngine}
        onOpenLabBot={() => setIsLabBotOpen(true)}
        onStartLiveVoice={() => setIsLiveVoiceOpen(true)}
        onOpenTranscribe={() => setIsTranscribeOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col">
        
        {/* Workspace Tab */}
        {activeTab === 'workspace' && (
          <>
            {activeExperimentId === 'titration-acid-base' ? (
              <div className="flex-1 flex flex-col justify-between">
                
                {/* Apparatus Stage */}
                <div className="relative flex-1 w-full min-h-[420px] flex items-center justify-center bg-slate-100">
                  
                  {/* Step Guidance Strip (Top of Workspace) */}
                  <div className="absolute top-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
                    
                    <div className="bg-white/95 border border-slate-200 rounded-xl px-3.5 py-1.5 shadow-2xs pointer-events-auto flex items-center gap-2 text-xs">
                      <span className="font-bold text-[#1F5FBF]">Step 3 of 5:</span>
                      <span className="text-slate-700 font-medium hidden sm:inline">
                        Add titrant dropwise near 24.10 mL until faint pink blush persists.
                      </span>
                      <span className="text-slate-700 font-medium sm:hidden">
                        Titrate until faint pink persists.
                      </span>
                    </div>

                    <div className="flex items-center gap-2 pointer-events-auto">
                      <button
                        onClick={() => setIsLiveVoiceOpen(true)}
                        className="bg-cyan-600 hover:bg-cyan-700 text-white px-3 py-1.5 rounded-xl shadow-2xs text-xs font-semibold flex items-center gap-1.5 transition-colors"
                        title="Start Gemini 3.8 Live API voice conversation"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Voice Conversation</span>
                        <span className="sm:hidden">Voice</span>
                      </button>

                      <button
                        onClick={() => setIsTranscribeOpen(true)}
                        className="bg-white hover:bg-slate-50 text-slate-700 px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs text-xs font-semibold flex items-center gap-1.5 transition-colors"
                        title="Transcribe speech with Gemini 3.5 Transcribe"
                      >
                        <Mic className="w-3.5 h-3.5 text-[#1F5FBF]" />
                        <span className="hidden sm:inline">Transcribe</span>
                      </button>

                      <button
                        onClick={() => setIsLabBotOpen(true)}
                        className="bg-white hover:bg-slate-50 text-slate-700 px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs text-xs font-semibold flex items-center gap-1.5 transition-colors"
                      >
                        <HelpCircle className="w-3.5 h-3.5 text-[#1F5FBF]" />
                        <span>Technique Hint</span>
                      </button>
                    </div>

                  </div>

                  {/* Dual-Mode Render Viewport (Three.js 3D or 2D Vector Fallback) */}
                  {engineMode === '3d' ? (
                    <ThreeJsLabViewport
                      state={simState}
                      cameraPreset={cameraPreset}
                      onFallbackTo2D={handleFallbackTo2D}
                    />
                  ) : (
                    <Canvas2DLabViewport
                      state={simState}
                      cameraPreset={cameraPreset}
                    />
                  )}

                </div>

                {/* Unified Collapsible Bottom Dock (<= 15% Viewport footprint) */}
                <CollapsibleBottomDock
                  state={simState}
                  onDispense={handleDispense}
                  onStepBack={handleStepBack}
                  onSwirl={handleSwirl}
                  onRefill={handleRefillBurette}
                  onResetFlask={handleResetFlask}
                  onRecordReading={handleRecordCurrentReading}
                  cameraPreset={cameraPreset}
                  setCameraPreset={setCameraPreset}
                />

              </div>
            ) : (
              <OhmsLawWorkspace level={level} />
            )}
          </>
        )}

        {/* Ledger Tab */}
        {activeTab === 'ledger' && (
          <ReadingsNotebookView
            trials={trials}
            onAddTrial={handleAddTrial}
            onDeleteTrial={handleDeleteTrial}
            onClearTrials={handleClearTrials}
            level={level}
            currentBuretteVolume={simState.dispensedVolume}
          />
        )}

        {/* Exam Quiz Tab */}
        {activeTab === 'quiz' && (
          <AssessmentQuizView
            onSaveResult={handleSaveQuizResult}
            savedResult={savedQuizResult}
          />
        )}

        {/* Library Tab */}
        {activeTab === 'library' && (
          <DashboardView
            level={level}
            setLevel={(l) => {
              setLevel(l);
              storageService.setSavedPreference('level', l);
            }}
            onLaunchExperiment={handleLaunchExperiment}
            activeExperimentId={activeExperimentId}
          />
        )}

      </main>

      {/* Real-Time Live API Voice Conversation Dock (gemini-3.8-live) */}
      <LiveVoiceFloatingBar
        isOpen={isLiveVoiceOpen}
        onClose={() => setIsLiveVoiceOpen(false)}
      />

      {/* Audio Transcription Modal (gemini-3.5-transcribe) */}
      <AudioTranscribeModal
        isOpen={isTranscribeOpen}
        onClose={() => setIsTranscribeOpen(false)}
        onTranscriptComplete={handleTranscriptComplete}
      />

      {/* Multilingual LabBot Modal */}
      <MultilingualAssistantModal
        isOpen={isLabBotOpen}
        onClose={() => {
          setIsLabBotOpen(false);
          setInjectedPrompt('');
        }}
        language={language}
        setLanguage={(l) => {
          setLanguage(l);
          storageService.setSavedPreference('language', l);
        }}
        currentDispensed={simState.dispensedVolume}
        onStartLiveVoice={() => setIsLiveVoiceOpen(true)}
        onOpenTranscribe={() => setIsTranscribeOpen(true)}
        injectedPrompt={injectedPrompt}
      />

      {/* Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <Info className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
