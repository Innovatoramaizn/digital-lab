/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AcademicLevel, EngineMode, SupportedLanguage } from '../types/lab.ts';
import { Bot, ChevronDown, Cpu, Mic, PhoneCall } from 'lucide-react';

interface TopAppBarProps {
  activeTab: 'workspace' | 'ledger' | 'quiz' | 'library';
  setActiveTab: (tab: 'workspace' | 'ledger' | 'quiz' | 'library') => void;
  level: AcademicLevel;
  setLevel: (level: AcademicLevel) => void;
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  engineMode: EngineMode;
  toggleEngineMode: () => void;
  onOpenLabBot: () => void;
  onStartLiveVoice: () => void;
  onOpenTranscribe: () => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({
  activeTab,
  setActiveTab,
  level,
  setLevel,
  language,
  setLanguage,
  engineMode,
  toggleEngineMode,
  onOpenLabBot,
  onStartLiveVoice,
  onOpenTranscribe,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-xs border-b border-slate-200 shadow-2xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2 sm:gap-6">
        
        {/* Zone 1: Brand Wordmark (Single line, no clutter) */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-[#1F5FBF] text-white flex items-center justify-center font-display font-bold text-lg shadow-xs">
            DL
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-slate-900 tracking-tight text-base sm:text-lg leading-tight whitespace-nowrap">
              Digital Lab
            </span>
            <span className="text-[10px] text-slate-500 font-medium whitespace-nowrap hidden sm:inline">
              WAEC · NECO · JAMB · 100L
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links (Single-line controls) */}
        <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto no-scrollbar py-1">
          <button
            onClick={() => setActiveTab('workspace')}
            className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'workspace'
                ? 'bg-[#D8E6FF] text-[#001B3F]'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Lab Workspace
          </button>
          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'ledger'
                ? 'bg-[#D8E6FF] text-[#001B3F]'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Readings Ledger
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'quiz'
                ? 'bg-[#D8E6FF] text-[#001B3F]'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Exam Quiz
          </button>
          <button
            onClick={() => setActiveTab('library')}
            className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'library'
                ? 'bg-[#D8E6FF] text-[#001B3F]'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Library
          </button>
        </nav>

        {/* Zone 3: Interactive Utilities (Level, AI Voice, Transcribe, Engine, LabBot) */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          
          {/* Level Toggle Button */}
          <div className="hidden lg:flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            <button
              onClick={() => setLevel('secondary')}
              className={`px-2 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                level === 'secondary'
                  ? 'bg-white text-[#1F5FBF] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Secondary
            </button>
            <button
              onClick={() => setLevel('tertiary')}
              className={`px-2 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                level === 'tertiary'
                  ? 'bg-white text-[#00696B] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tertiary
            </button>
          </div>

          {/* Dialect / Language Selector */}
          <div className="relative">
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as SupportedLanguage)}
              className="appearance-none bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 text-xs font-medium py-1.5 pl-2 pr-6 rounded-lg cursor-pointer transition-colors focus:outline-none focus:ring-2 focus:ring-[#1F5FBF]"
              aria-label="Select lab dialect"
            >
              <option value="en">English</option>
              <option value="pcm">Pidgin</option>
              <option value="yo">Yorùbá</option>
              <option value="ha">Hausa</option>
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-2.5 pointer-events-none" />
          </div>

          {/* Live Voice Conversation Button (Gemini 3.8 Live) */}
          <button
            onClick={onStartLiveVoice}
            title="Start real-time voice conversation with Gemini 3.8 Live API"
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-700 text-white text-xs font-semibold shadow-2xs transition-colors whitespace-nowrap"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Live Voice</span>
          </button>

          {/* Transcribe Audio Button (Gemini 3.5 Transcribe) */}
          <button
            onClick={onOpenTranscribe}
            title="Transcribe speech with Gemini 3.5 Transcribe"
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 text-xs font-semibold transition-colors whitespace-nowrap"
          >
            <Mic className="w-3.5 h-3.5 text-[#1F5FBF]" />
            <span className="hidden md:inline">Transcribe</span>
          </button>

          {/* Engine Mode Switcher (3D vs 2D Fallback) */}
          <button
            onClick={toggleEngineMode}
            title={engineMode === '3d' ? '3D Three.js active (Click for 2D mode)' : '2D Canvas active (Click for 3D mode)'}
            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg border text-xs font-medium transition-all ${
              engineMode === '3d'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100'
                : 'bg-amber-50 border-amber-200 text-amber-800 hover:bg-amber-100'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span className="hidden xl:inline">{engineMode === '3d' ? '3D' : '2D'}</span>
          </button>

          {/* LabBot Trigger */}
          <button
            onClick={onOpenLabBot}
            className="flex items-center gap-1.5 bg-[#1F5FBF] hover:bg-[#154694] text-white px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-medium transition-all shadow-xs"
            aria-label="Open AI Lab Assistant"
          >
            <Bot className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">LabBot</span>
          </button>

        </div>

      </div>
    </header>
  );
};
