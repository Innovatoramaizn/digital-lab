/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { transcriptionClient } from '../services/transcriptionClient.ts';
import { Check, Copy, Mic, MicOff, RefreshCw, Send, Sparkles, X } from 'lucide-react';

interface AudioTranscribeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTranscriptComplete?: (transcript: string) => void;
}

export const AudioTranscribeModal: React.FC<AudioTranscribeModalProps> = ({
  isOpen,
  onClose,
  onTranscriptComplete,
}) => {
  const [recordingState, setRecordingState] = useState<'idle' | 'recording' | 'transcribing' | 'done'>('idle');
  const [transcript, setTranscript] = useState<string>('');
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (recordingState === 'recording') {
      timer = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      setRecordingSeconds(0);
    }
    return () => clearInterval(timer);
  }, [recordingState]);

  if (!isOpen) return null;

  const handleStartRecording = async () => {
    setErrorMessage(null);
    setTranscript('');
    try {
      await transcriptionClient.startRecording();
      setRecordingState('recording');
    } catch (err: any) {
      console.error('Record error:', err);
      setErrorMessage(err?.message || 'Could not access microphone');
      setRecordingState('idle');
    }
  };

  const handleStopAndTranscribe = async () => {
    setRecordingState('transcribing');
    try {
      const text = await transcriptionClient.stopAndTranscribe();
      setTranscript(text);
      setRecordingState('done');
      if (onTranscriptComplete) {
        onTranscriptComplete(text);
      }
    } catch (err: any) {
      console.error('Transcribe error:', err);
      setErrorMessage(err?.message || 'Failed to transcribe audio with gemini-3.5-transcribe');
      setRecordingState('idle');
    }
  };

  const handleCopy = () => {
    if (!transcript) return;
    navigator.clipboard.writeText(transcript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-[#1F5FBF] px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center">
              <Mic className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base">Transcribe Audio</h2>
              <p className="text-[11px] text-blue-100 font-mono">
                Model: gemini-3.5-transcribe
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              transcriptionClient.cancel();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
            aria-label="Close transcribe modal"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          
          <p className="text-xs text-slate-600 leading-relaxed">
            Record a science question, laboratory observation, or titration note with your microphone. Gemini 3.5 Transcribe will convert your speech to text.
          </p>

          {/* Recording Status Stage */}
          <div className="flex flex-col items-center justify-center py-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-3">
            
            {recordingState === 'idle' && (
              <button
                onClick={handleStartRecording}
                className="w-16 h-16 rounded-full bg-[#1F5FBF] hover:bg-[#154694] text-white flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all"
                aria-label="Start recording microphone"
              >
                <Mic className="w-7 h-7" />
              </button>
            )}

            {recordingState === 'recording' && (
              <div className="flex flex-col items-center space-y-3">
                <button
                  onClick={handleStopAndTranscribe}
                  className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow-lg animate-pulse"
                  aria-label="Stop recording and transcribe"
                >
                  <div className="w-6 h-6 rounded-xs bg-white" />
                </button>
                <div className="flex items-center gap-2 text-red-600 font-mono text-sm font-bold">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
                  <span>Recording: 00:{recordingSeconds < 10 ? `0${recordingSeconds}` : recordingSeconds}</span>
                </div>
              </div>
            )}

            {recordingState === 'transcribing' && (
              <div className="flex flex-col items-center space-y-2 text-[#1F5FBF]">
                <RefreshCw className="w-8 h-8 animate-spin" />
                <span className="text-xs font-semibold">Transcribing with gemini-3.5-transcribe...</span>
              </div>
            )}

            {recordingState === 'done' && (
              <button
                onClick={handleStartRecording}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Record Again</span>
              </button>
            )}

            <span className="text-[11px] text-slate-400 font-medium">
              {recordingState === 'idle' && 'Tap microphone to speak'}
              {recordingState === 'recording' && 'Tap red square when finished'}
              {recordingState === 'transcribing' && 'Analyzing audio waveforms...'}
              {recordingState === 'done' && 'Transcription complete'}
            </span>

          </div>

          {/* Transcript Output Box */}
          {transcript && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700">Transcription Result:</span>
                <button
                  onClick={handleCopy}
                  className="text-xs text-[#1F5FBF] hover:underline flex items-center gap-1"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>

              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 font-medium leading-relaxed max-h-40 overflow-y-auto">
                {transcript}
              </div>
            </div>
          )}

          {errorMessage && (
            <p className="text-xs text-red-600 bg-red-50 p-2.5 rounded-xl border border-red-200">
              {errorMessage}
            </p>
          )}

          {/* Footer actions */}
          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => {
                transcriptionClient.cancel();
                onClose();
              }}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl"
            >
              Close
            </button>
            {transcript && (
              <button
                onClick={() => {
                  if (onTranscriptComplete) onTranscriptComplete(transcript);
                  onClose();
                }}
                className="px-4 py-2 bg-[#1F5FBF] hover:bg-[#154694] text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5"
              >
                <span>Use Transcript</span>
              </button>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
