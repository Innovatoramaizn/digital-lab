/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SupportedLanguage } from '../types/lab.ts';
import { audioSpeechService } from '../services/audioSpeechService.ts';
import { Bot, Check, Eye, HelpCircle, MessageSquare, Mic, PhoneCall, RefreshCw, Send, Sparkles, Volume2, X } from 'lucide-react';

interface MultilingualAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  currentDispensed: number;
  onStartLiveVoice: () => void;
  onOpenTranscribe: () => void;
  injectedPrompt?: string;
}

interface DialectContent {
  greeting: string;
  endpointAdvice: string;
  parallaxAdvice: string;
  concordanceAdvice: string;
  rinsingAdvice: string;
}

const DIALECT_DATA: Record<SupportedLanguage, DialectContent> = {
  en: {
    greeting: 'Welcome to Digital Lab! I am LabBot, your interactive science practical tutor.',
    endpointAdvice: 'Watch the flask closely as you approach 24.00 mL. Switch to +0.1 mL dropwise and swirl after every drop until a faint, delicate pink blush remains permanently.',
    parallaxAdvice: 'Always keep your eyes strictly level with the bottom of the curved meniscus line to prevent parallax errors. Never look down from above or up from below.',
    concordanceAdvice: 'In WAEC, your non-rough trials must have a spread of 0.10 mL or less (e.g., 24.10 and 24.20 mL). Always exclude the rough trial when calculating your mean titre.',
    rinsingAdvice: 'Always rinse the burette with a small portion of the acid solution after washing with distilled water to prevent dilution of your standard reagent.',
  },
  pcm: {
    greeting: 'Welcome to Digital Lab! Na me be LabBot, your personal chemistry practical tutor for Naija!',
    endpointAdvice: 'As your acid reading dey reach 24.00 mL, begin dey add am drop-by-drop with the +0.1 mL button. Swirl the flask well-well. The moment e turn faint pink, stop sharp-sharp!',
    parallaxAdvice: 'Make your eye dey directly level with the bottom curve of the meniscus liquid! If you look am from up or down, your reading go spoil and WAEC go deduct marks.',
    concordanceAdvice: 'For WAEC paper, your two concordant readings must no pass 0.10 mL difference (e.g. 24.10 and 24.20 mL). No ever add rough trial inside your average calculation!',
    rinsingAdvice: 'After you wash your burette with clean water, rinse am with small acid make the water drops no go dilute the acid concentration.',
  },
  yo: {
    greeting: 'Ẹ ku abọ si Digital Lab! Emi ni LabBot, olukọni yàrá-ẹkọ imọ-ijinlẹ rẹ.',
    endpointAdvice: 'Nigba ti kika rẹ ba de 24.00 mL, ẹ bẹrẹ si ni fi ọwọ pẹlẹbẹ rọ acid naa silẹ ni ẹyọ-kọọkan (+0.1 mL). Ẹ maa gbọn ife conical flask naa. Nigba ti awọ rẹ ba di pupa fẹrẹfẹ ti ko pada mọ, ẹ duro!',
    parallaxAdvice: 'Ẹ ri daju wipe oju yin wa ni ipele gangan pẹlu isalẹ ila omi (meniscus). Ma wo lati oke tabi isalẹ ki ẹ ma baa ṣe aṣiṣe parallax.',
    concordanceAdvice: 'Ninu idanwo WAEC, iyatọ laarin awọn idanwo rẹ meji ti o baamu ko gbọdọ ju 0.10 mL lọ. Ẹ ma ṣe fi idanwo aṣọtẹlẹ (rough trial) pọ mọ iṣiro ipari.',
    rinsingAdvice: 'Lẹhin ti ẹ ba fi omi fọ burette rẹ tan, ẹ fi acid diẹ fo inu rẹ ki omi ma baa dinku agbara acid naa.',
  },
  ha: {
    greeting: 'Barka da zuwa Digital Lab! Ni ne LabBot, malamin ku na gwajin kimiyya.',
    endpointAdvice: 'Idan acid din ya kai kusan 24.00 mL, ka fara zuba shi digo-digo (+0.1 mL). Ka rika motsa kwanon flask din. Da zaran kalar ta zama ruwan hoda mai haske da bata bace ba, to an gama!',
    parallaxAdvice: 'Koyaushe ka tabbatar idanunka suna daidai da kasan layin ruwan (meniscus). Kada ka kalla daga sama ko kasa don guje wa kuskuren parallax.',
    concordanceAdvice: 'A jarabawar WAEC, bambanci tsakanin sakamakon da ya dace kada ya wuce 0.10 mL. Kada a taba saka sakamakon farko (rough trial) a cikin lissafin matsakaici.',
    rinsingAdvice: 'Bayan wanke bututun burette da ruwa mai tsarki, a dan kurkure shi da kadan daga cikin acid din don kar ruwa ya rage karfin sinadarin.',
  },
};

export const MultilingualAssistantModal: React.FC<MultilingualAssistantModalProps> = ({
  isOpen,
  onClose,
  language,
  setLanguage,
  currentDispensed,
  onStartLiveVoice,
  onOpenTranscribe,
  injectedPrompt,
}) => {
  const [activeTopic, setActiveTopic] = useState<'endpoint' | 'parallax' | 'concordance' | 'rinsing'>('endpoint');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [chatQuery, setChatQuery] = useState(injectedPrompt || '');
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  React.useEffect(() => {
    if (injectedPrompt) {
      setChatQuery(injectedPrompt);
    }
  }, [injectedPrompt]);

  if (!isOpen) return null;

  const content = DIALECT_DATA[language] || DIALECT_DATA.en;

  const getTopicText = () => {
    switch (activeTopic) {
      case 'endpoint':
        return content.endpointAdvice;
      case 'parallax':
        return content.parallaxAdvice;
      case 'concordance':
        return content.concordanceAdvice;
      case 'rinsing':
        return content.rinsingAdvice;
    }
  };

  const handleSpeakText = (text: string) => {
    setIsPlayingAudio(true);
    audioSpeechService.speak(text, language);
    setTimeout(() => setIsPlayingAudio(false), 5000);
  };

  const handleAskGemini = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatQuery.trim() || isLoadingAi) return;

    setIsLoadingAi(true);
    setAiAnswer(null);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: chatQuery,
          language,
          context: {
            currentDispensedVolume: currentDispensed,
            analyte: 'NaOH',
            titrant: '0.100 M HCl',
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }

      const data = await response.json();
      setAiAnswer(data.text || 'No response generated.');
    } catch (err: any) {
      console.warn('AI query error:', err);
      // Fallback response grounded in syllabus rules
      setAiAnswer(`LabBot Advice: When titrating at ${currentDispensed.toFixed(2)} mL, ensure the conical flask is swirled continuously. If near 24.15 mL, add dropwise (+0.1 mL).`);
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-auto">
        
        {/* Header */}
        <div className="bg-[#1F5FBF] px-5 sm:px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-base sm:text-lg">LabBot Multilingual Tutor</h2>
              <p className="text-xs text-blue-100">
                Live Voice API & Transcription Enabled
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
            aria-label="Close assistant"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* AI Action Badges Banner */}
        <div className="bg-slate-900 px-5 sm:px-6 py-2.5 text-white flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-slate-300 flex items-center gap-1.5 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Interactive AI Features:</span>
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onStartLiveVoice();
              }}
              className="flex items-center gap-1.5 px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-bold text-[11px] transition-colors shadow-2xs"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Voice Conversation (Live API)</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onOpenTranscribe();
              }}
              className="flex items-center gap-1.5 px-3 py-1 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded-lg font-semibold text-[11px] transition-colors"
            >
              <Mic className="w-3 h-3 text-cyan-400" />
              <span>Transcribe Audio</span>
            </button>
          </div>
        </div>

        {/* Dialect Switcher Pill Strip */}
        <div className="px-5 sm:px-6 pt-3 pb-2 border-b border-slate-100 flex items-center justify-between gap-2 overflow-x-auto">
          <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">
            Dialect:
          </span>
          <div className="flex items-center gap-1.5">
            {(['en', 'pcm', 'yo', 'ha'] as SupportedLanguage[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                  language === lang
                    ? 'bg-[#D8E6FF] text-[#001B3F]'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {lang === 'en' && 'English'}
                {lang === 'pcm' && 'Naija Pidgin'}
                {lang === 'yo' && 'Yorùbá'}
                {lang === 'ha' && 'Hausa'}
              </button>
            ))}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          
          {/* Greeting Box */}
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-700 leading-relaxed">
            {content.greeting}
          </div>

          {/* Ask LabBot Form with Server-Side Gemini */}
          <form onSubmit={handleAskGemini} className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              Ask any practical question (type or transcribe):
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. Why did my solution overshoot into deep magenta?"
                value={chatQuery}
                onChange={(e) => setChatQuery(e.target.value)}
                className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#1F5FBF]"
              />
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenTranscribe();
                }}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors border border-slate-200"
                title="Speak question using Microphone Transcribe (gemini-3.5-transcribe)"
              >
                <Mic className="w-4 h-4 text-[#1F5FBF]" />
              </button>
              <button
                type="submit"
                disabled={isLoadingAi || !chatQuery.trim()}
                className="px-4 py-2 bg-[#1F5FBF] hover:bg-[#154694] disabled:opacity-40 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1 shadow-2xs"
              >
                {isLoadingAi ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>Ask</span>
              </button>
            </div>
          </form>

          {/* AI Response Card if available */}
          {aiAnswer && (
            <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-900">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>LabBot AI Answer:</span>
                </span>
                <button
                  onClick={() => handleSpeakText(aiAnswer)}
                  className="text-emerald-700 hover:text-emerald-900 flex items-center gap-1 text-[11px]"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen</span>
                </button>
              </div>
              <p className="text-xs text-slate-800 leading-relaxed font-medium">
                {aiAnswer}
              </p>
            </div>
          )}

          {/* Core Practical Topics Tabs */}
          <div className="space-y-2 pt-2">
            <span className="text-xs font-semibold text-slate-500 block">
              Quick Practical Guidance:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              <button
                onClick={() => setActiveTopic('endpoint')}
                className={`p-2 rounded-xl text-xs font-semibold text-center transition-all ${
                  activeTopic === 'endpoint'
                    ? 'bg-[#1F5FBF] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Endpoint
              </button>
              <button
                onClick={() => setActiveTopic('parallax')}
                className={`p-2 rounded-xl text-xs font-semibold text-center transition-all ${
                  activeTopic === 'parallax'
                    ? 'bg-[#1F5FBF] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Meniscus
              </button>
              <button
                onClick={() => setActiveTopic('concordance')}
                className={`p-2 rounded-xl text-xs font-semibold text-center transition-all ${
                  activeTopic === 'concordance'
                    ? 'bg-[#1F5FBF] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Concordance
              </button>
              <button
                onClick={() => setActiveTopic('rinsing')}
                className={`p-2 rounded-xl text-xs font-semibold text-center transition-all ${
                  activeTopic === 'rinsing'
                    ? 'bg-[#1F5FBF] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Rinsing
              </button>
            </div>
          </div>

          {/* Topic Detail */}
          <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100 space-y-3">
            <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-medium">
              {getTopicText()}
            </p>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-slate-500 font-mono">
                Burette: {currentDispensed.toFixed(2)} mL
              </span>

              <button
                onClick={() => handleSpeakText(getTopicText())}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs transition-colors"
              >
                <Volume2 className="w-3.5 h-3.5 text-[#1F5FBF]" />
                <span>{isPlayingAudio ? 'Speaking...' : 'Play Voice Note'}</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
