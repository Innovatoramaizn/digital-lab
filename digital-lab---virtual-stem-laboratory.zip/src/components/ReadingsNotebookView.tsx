/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AcademicLevel, TitrationTrial } from '../types/lab.ts';
import { TitrationEngine } from '../services/titrationEngine.ts';
import { CheckCircle2, Download, FileSpreadsheet, Info, Plus, Trash2, XCircle } from 'lucide-react';

interface ReadingsNotebookViewProps {
  trials: TitrationTrial[];
  onAddTrial: (trial: TitrationTrial) => void;
  onDeleteTrial: (id: string) => void;
  onClearTrials: () => void;
  level: AcademicLevel;
  currentBuretteVolume: number;
}

export const ReadingsNotebookView: React.FC<ReadingsNotebookViewProps> = ({
  trials,
  onAddTrial,
  onDeleteTrial,
  onClearTrials,
  level,
  currentBuretteVolume,
}) => {
  const [initialInput, setInitialInput] = useState<string>('0.00');
  const [finalInput, setFinalInput] = useState<string>(currentBuretteVolume.toFixed(2));
  const [isRough, setIsRough] = useState<boolean>(trials.length === 0);
  const [userMolarity, setUserMolarity] = useState<string>('');
  const [showCalculationSteps, setShowCalculationSteps] = useState<boolean>(false);

  // Evaluate concordance
  const concordanceResult = TitrationEngine.evaluateConcordance(trials);

  // Handle manual or automatic trial entry
  const handleRecordNew = (e: React.FormEvent) => {
    e.preventDefault();
    const init = parseFloat(initialInput) || 0;
    const fin = parseFloat(finalInput) || 0;
    const titre = Number(Math.max(0, fin - init).toFixed(2));

    const trialNumber = trials.length === 0 ? 0 : trials.length;
    const label = trialNumber === 0 ? 'Rough Trial' : `Trial ${trialNumber}`;

    const newTrial: TitrationTrial = {
      id: `trial_${Date.now()}`,
      trialNumber,
      label,
      isRough: isRough || trialNumber === 0,
      initialReading: init,
      finalReading: fin,
      titre,
      timestamp: Date.now(),
    };

    onAddTrial(newTrial);
    setInitialInput(fin.toFixed(2));
    setFinalInput(fin.toFixed(2));
    setIsRough(false);
  };

  // CSV Export
  const exportCSV = () => {
    let csv = 'Trial,Type,Initial Reading (mL),Final Reading (mL),Titre (mL)\n';
    trials.forEach((t) => {
      csv += `"${t.label}","${t.isRough ? 'Rough' : 'Titre'}","${t.initialReading.toFixed(2)}","${t.finalReading.toFixed(2)}","${t.titre.toFixed(2)}"\n`;
    });
    if (concordanceResult.averageTitre !== null) {
      csv += `\n"Average Titre (Concordant)","","","","${concordanceResult.averageTitre.toFixed(2)} mL"\n`;
    }

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `WAEC_Titration_Ledger_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Calculated acid concentration
  const theoreticalMean = concordanceResult.averageTitre || 24.15;
  const standardBaseConc = 0.0966; // mol/dm^3
  const aliquot = 25.0; // mL
  const calculatedAcidConc = TitrationEngine.calculateAcidConcentration(
    standardBaseConc,
    theoreticalMean,
    aliquot,
    1,
    1
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8 space-y-8">
      
      {/* Title & Header Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Volumetric Analysis Laboratory Notebook
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Official WAEC/NECO Paper 3 Tabular Ledger & Stoichiometric Deductions
          </p>
        </div>

        <div className="flex items-center gap-2">
          {trials.length > 0 && (
            <>
              <button
                onClick={exportCSV}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold shadow-2xs transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
              <button
                onClick={onClearTrials}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-red-200 text-red-700 hover:bg-red-50 text-xs font-medium transition-colors"
                title="Clear all recorded trials"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Reset Ledger</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Official Titration Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <span className="font-semibold text-slate-900 text-sm sm:text-base">
            Table of Titration Results (Burette Readings)
          </span>
          <span className="text-xs text-slate-500 font-mono">
            Unit: cm³ (mL)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 text-xs font-semibold border-b border-slate-200">
                <th className="py-3 px-4 w-48">Burette Readings</th>
                <th className="py-3 px-4 text-center">Rough Trial</th>
                <th className="py-3 px-4 text-center">1st Titre</th>
                <th className="py-3 px-4 text-center">2nd Titre</th>
                <th className="py-3 px-4 text-center">3rd Titre</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs sm:text-sm font-mono tabular-nums">
              
              {/* Row 1: Final Burette Reading */}
              <tr>
                <td className="py-3 px-4 font-sans font-medium text-slate-700 bg-slate-50/50">
                  Final Reading (cm³)
                </td>
                {[0, 1, 2, 3].map((num) => {
                  const t = trials.find((item) => item.trialNumber === num);
                  return (
                    <td key={`final_${num}`} className="py-3 px-4 text-center text-slate-900 font-semibold">
                      {t ? t.finalReading.toFixed(2) : '—'}
                    </td>
                  );
                })}
              </tr>

              {/* Row 2: Initial Burette Reading */}
              <tr>
                <td className="py-3 px-4 font-sans font-medium text-slate-700 bg-slate-50/50">
                  Initial Reading (cm³)
                </td>
                {[0, 1, 2, 3].map((num) => {
                  const t = trials.find((item) => item.trialNumber === num);
                  return (
                    <td key={`initial_${num}`} className="py-3 px-4 text-center text-slate-700">
                      {t ? t.initialReading.toFixed(2) : '—'}
                    </td>
                  );
                })}
              </tr>

              {/* Row 3: Volume of Acid Used (Titre) */}
              <tr className="bg-blue-50/30">
                <td className="py-3 px-4 font-sans font-bold text-[#001B3F] bg-blue-100/30">
                  Volume of Titrant (cm³)
                </td>
                {[0, 1, 2, 3].map((num) => {
                  const t = trials.find((item) => item.trialNumber === num);
                  const isConcordant = t && concordanceResult.concordantIndices.includes(t.trialNumber);
                  return (
                    <td
                      key={`titre_${num}`}
                      className={`py-3 px-4 text-center font-bold ${
                        num === 0
                          ? 'text-slate-500' // Rough trial
                          : isConcordant
                          ? 'text-emerald-700 bg-emerald-50'
                          : 'text-slate-900'
                      }`}
                    >
                      {t ? (
                        <div className="flex items-center justify-center gap-1">
                          <span>{t.titre.toFixed(2)}</span>
                          {isConcordant && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          )}
                        </div>
                      ) : (
                        '—'
                      )}
                    </td>
                  );
                })}
              </tr>

            </tbody>
          </table>
        </div>

        {/* Concordance Assessment Alert Banner */}
        <div className="p-4 bg-slate-50 border-t border-slate-100">
          <div className="flex items-start gap-3">
            {concordanceResult.isConcordant ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            )}
            <div className="space-y-1">
              <span className="text-xs sm:text-sm font-semibold text-slate-900">
                WAEC Concordance Rule Check:
              </span>
              <p className="text-xs text-slate-600">
                {concordanceResult.feedbackMessage}
              </p>
              {concordanceResult.averageTitre !== null && (
                <div className="pt-2 flex items-baseline gap-2">
                  <span className="text-xs font-semibold text-slate-700 font-sans">
                    Average Volume of Acid Used (V_A):
                  </span>
                  <span className="text-base font-bold text-[#1F5FBF] font-mono">
                    {concordanceResult.averageTitre.toFixed(2)} cm³
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

      </div>

      {/* Record a New Trial Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
        <h2 className="text-sm sm:text-base font-bold text-slate-900 mb-3">
          Add Trial Entry to Ledger
        </h2>
        
        <form onSubmit={handleRecordNew} className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-end">
          
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Initial Reading (cm³)
            </label>
            <input
              type="number"
              step="0.05"
              min="0"
              max="50"
              value={initialInput}
              onChange={(e) => setInitialInput(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#1F5FBF]"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Final Reading (cm³)
            </label>
            <input
              type="number"
              step="0.05"
              min="0"
              max="50"
              value={finalInput}
              onChange={(e) => setFinalInput(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#1F5FBF]"
              required
            />
          </div>

          <div className="flex items-center gap-2 pb-2">
            <input
              type="checkbox"
              id="isRoughCheck"
              checked={isRough}
              onChange={(e) => setIsRough(e.target.checked)}
              className="w-4 h-4 text-[#1F5FBF] rounded border-slate-300 focus:ring-[#1F5FBF]"
            />
            <label htmlFor="isRoughCheck" className="text-xs font-medium text-slate-700 cursor-pointer">
              Mark as Rough Trial
            </label>
          </div>

          <button
            type="submit"
            className="w-full min-h-[44px] px-4 py-2 bg-[#1F5FBF] hover:bg-[#154694] text-white text-xs font-bold rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Save to Table</span>
          </button>

        </form>
      </div>

      {/* Stoichiometric Deduction Engine */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
        
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">
              Stoichiometric Concentration Deduction
            </h2>
            <p className="text-xs text-slate-600">
              Applying the volumetric mole ratio formula: (C_A × V_A) / (C_B × V_B) = n_A / n_B
            </p>
          </div>
          <button
            onClick={() => setShowCalculationSteps(!showCalculationSteps)}
            className="text-xs font-semibold text-[#1F5FBF] hover:underline"
          >
            {showCalculationSteps ? 'Hide Full Derivation' : 'Show Full Derivation'}
          </button>
        </div>

        {/* Known Parameters Card */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-100 font-mono">
          <div>
            <span className="text-slate-500 block font-sans">Base (B) Aliquot V_B:</span>
            <span className="text-sm font-bold text-slate-900">25.00 cm³</span>
          </div>
          <div>
            <span className="text-slate-500 block font-sans">Base Molarity C_B:</span>
            <span className="text-sm font-bold text-slate-900">0.0966 mol dm⁻³</span>
          </div>
          <div>
            <span className="text-slate-500 block font-sans">Mole Ratio n_A / n_B:</span>
            <span className="text-sm font-bold text-slate-900">1 : 1</span>
          </div>
          <div>
            <span className="text-slate-500 block font-sans">Your Mean Titre V_A:</span>
            <span className="text-sm font-bold text-[#1F5FBF]">
              {concordanceResult.averageTitre ? `${concordanceResult.averageTitre.toFixed(2)} cm³` : '24.15 cm³ (ideal)'}
            </span>
          </div>
        </div>

        {/* Interactive Student Answer Check */}
        <div className="pt-2 flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex-1">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Your Calculated Acid Concentration C_A (mol dm⁻³):
            </label>
            <input
              type="number"
              step="0.0001"
              placeholder="e.g. 0.1000"
              value={userMolarity}
              onChange={(e) => setUserMolarity(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono text-sm focus:outline-none focus:ring-2 focus:ring-[#1F5FBF]"
            />
          </div>

          {userMolarity && (
            <div className="pt-5 sm:pt-0">
              {Math.abs(parseFloat(userMolarity) - calculatedAcidConc) <= 0.005 ? (
                <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-200">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Correct! Concordant with WAEC standard (0.100 mol dm⁻³)</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-amber-700 text-xs font-medium bg-amber-50 px-3 py-2 rounded-xl border border-amber-200">
                  <XCircle className="w-4 h-4" />
                  <span>Check calculation: Expected ~{calculatedAcidConc.toFixed(4)} mol dm⁻³</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Step-by-Step Derivation View */}
        {showCalculationSteps && (
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3 font-mono text-xs text-slate-800">
            <div className="font-sans font-bold text-slate-900 text-sm">
              Examiner Marking Scheme Step-by-Step:
            </div>
            <p>1. Balanced Chemical Equation: HCl(aq) + NaOH(aq) → NaCl(aq) + H₂O(l)</p>
            <p>2. Mole ratio: n(HCl) : n(NaOH) = 1 : 1</p>
            <p>3. Formula: (C_A × V_A) / (C_B × V_B) = 1 / 1</p>
            <p>4. Rearranging for C_A: C_A = (C_B × V_B) / V_A</p>
            <p className="text-[#1F5FBF] font-bold">
              5. Substituting: C_A = (0.0966 × 25.00) / {theoreticalMean.toFixed(2)} = {calculatedAcidConc.toFixed(4)} mol dm⁻³
            </p>
          </div>
        )}

      </div>

    </div>
  );
};
