/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Camera, ChevronDown, ChevronUp, Droplets, RotateCcw, Save, Sparkles, Wind } from 'lucide-react';
import { TitrationState } from '../types/lab.ts';

interface CollapsibleBottomDockProps {
  state: TitrationState;
  onDispense: (amount: number) => void;
  onStepBack: () => void;
  onSwirl: () => void;
  onRefill: () => void;
  onResetFlask: () => void;
  onRecordReading: () => void;
  cameraPreset: 'overview' | 'burette' | 'flask';
  setCameraPreset: (preset: 'overview' | 'burette' | 'flask') => void;
}

export const CollapsibleBottomDock: React.FC<CollapsibleBottomDockProps> = ({
  state,
  onDispense,
  onStepBack,
  onSwirl,
  onRefill,
  onResetFlask,
  onRecordReading,
  cameraPreset,
  setCameraPreset,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <div className="w-full bg-white border-t border-slate-200 shadow-lg transition-all duration-300">
      
      {/* Collapse / Expand Tab */}
      <div className="flex justify-center -mt-3.5 pointer-events-auto">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="flex items-center gap-1.5 px-4 py-1 bg-white border border-slate-200 rounded-full text-[11px] font-semibold text-slate-600 hover:text-slate-900 shadow-xs hover:bg-slate-50 transition-colors"
          aria-expanded={!isCollapsed}
          aria-label={isCollapsed ? 'Show laboratory controls dock' : 'Hide laboratory controls dock'}
        >
          {isCollapsed ? (
            <>
              <ChevronUp className="w-3.5 h-3.5" />
              <span>Show Controls</span>
            </>
          ) : (
            <>
              <ChevronDown className="w-3.5 h-3.5" />
              <span>Hide Controls</span>
            </>
          )}
        </button>
      </div>

      {!isCollapsed && (
        <div className="max-w-6xl mx-auto px-4 py-3 sm:py-4">
          
          {/* Top Info Bar: Reading & Chemical Status */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
            
            {/* Live Reading Display (Accessible DOM with aria-live) */}
            <div className="flex items-center gap-3">
              <div className="bg-[#D8E6FF] text-[#001B3F] px-3.5 py-1.5 rounded-xl flex items-baseline gap-1.5 shadow-2xs">
                <span className="text-xs font-medium uppercase tracking-wider text-slate-600">Burette:</span>
                <span
                  className="font-mono text-xl sm:text-2xl font-bold tabular-nums"
                  aria-live="polite"
                  aria-atomic="true"
                >
                  {state.dispensedVolume.toFixed(2)}
                </span>
                <span className="text-xs font-semibold text-slate-700">mL</span>
              </div>

              {/* Indicator & Chemical State (Never color alone) */}
              <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-xl border border-slate-200">
                <div
                  className="w-4 h-4 rounded-full border border-slate-300 shadow-2xs shrink-0"
                  style={{ backgroundColor: state.colorHex }}
                  aria-hidden="true"
                />
                <span className="text-xs font-semibold text-slate-800">
                  {state.colorLabel}
                </span>
                <span className="text-[11px] font-mono text-slate-500 hidden sm:inline">
                  (pH {state.pH})
                </span>
              </div>
            </div>

            {/* Camera Presets Selector */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
              <Camera className="w-3.5 h-3.5 text-slate-500 ml-1.5 mr-0.5" />
              <button
                onClick={() => setCameraPreset('overview')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  cameraPreset === 'overview'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setCameraPreset('burette')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  cameraPreset === 'burette'
                    ? 'bg-white text-[#1F5FBF] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Burette (Zoom)
              </button>
              <button
                onClick={() => setCameraPreset('flask')}
                className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  cameraPreset === 'flask'
                    ? 'bg-white text-[#00696B] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Flask View
              </button>
            </div>

          </div>

          {/* Action Buttons Grid (Meeting 48x48dp minimum touch target rule) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2 pt-3">
            
            {/* Step Back (-1.0 mL) */}
            <button
              onClick={onStepBack}
              disabled={state.dispensedVolume <= 0}
              className="min-h-[48px] px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 active:scale-95 shadow-2xs"
            >
              <span>−1.0 mL</span>
            </button>

            {/* Precision Micro-Titration (+0.1 mL Dropwise) - High Focal Intent */}
            <button
              onClick={() => onDispense(0.1)}
              disabled={state.dispensedVolume >= state.buretteCapacity}
              className="min-h-[48px] col-span-1 sm:col-span-1 px-3 py-2 rounded-xl bg-[#1F5FBF] hover:bg-[#154694] text-white text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 active:scale-95 shadow-xs"
            >
              <Droplets className="w-4 h-4" />
              <span>+0.1 mL Dropwise</span>
            </button>

            {/* Rapid Add (+1.0 mL) */}
            <button
              onClick={() => onDispense(1.0)}
              disabled={state.dispensedVolume >= state.buretteCapacity}
              className="min-h-[48px] px-3 py-2 rounded-xl border border-[#1F5FBF]/30 bg-[#D8E6FF]/50 hover:bg-[#D8E6FF] text-[#001B3F] text-xs font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 active:scale-95 shadow-2xs"
            >
              <span>+1.0 mL Rapid</span>
            </button>

            {/* Kinetic Swirling */}
            <button
              onClick={onSwirl}
              className={`min-h-[48px] px-3 py-2 rounded-xl border text-xs font-semibold transition-all flex items-center justify-center gap-1.5 active:scale-95 shadow-2xs ${
                state.isSwirling
                  ? 'bg-amber-100 border-amber-300 text-amber-900 animate-pulse'
                  : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
              }`}
            >
              <Wind className="w-4 h-4 text-amber-600" />
              <span>{state.isSwirling ? 'Swirling...' : 'Swirl Flask'}</span>
            </button>

            {/* Record Trial into Ledger */}
            <button
              onClick={onRecordReading}
              className="min-h-[48px] px-3 py-2 rounded-xl bg-[#00696B] hover:bg-[#004D4E] text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 active:scale-95 shadow-xs"
            >
              <Save className="w-4 h-4" />
              <span>Record Reading</span>
            </button>

            {/* Refill Burette */}
            <button
              onClick={onRefill}
              className="min-h-[48px] px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium transition-all flex items-center justify-center gap-1.5 active:scale-95 shadow-2xs"
              title="Reset liquid level to 0.00 mL line"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
              <span>Refill Burette</span>
            </button>

            {/* Reset Flask Aliquot */}
            <button
              onClick={onResetFlask}
              className="min-h-[48px] px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium transition-all flex items-center justify-center gap-1.5 active:scale-95 shadow-2xs"
              title="Empty flask and pipette fresh 25 mL aliquot"
            >
              <span>Fresh Flask</span>
            </button>

          </div>

        </div>
      )}

    </div>
  );
};
