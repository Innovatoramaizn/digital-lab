/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { QuizQuestion, QuizResult } from '../types/lab.ts';
import { CheckCircle2, ChevronRight, HelpCircle, RotateCcw, Trophy, XCircle } from 'lucide-react';

interface AssessmentQuizViewProps {
  onSaveResult: (result: QuizResult) => void;
  savedResult: QuizResult | null;
}

const WAEC_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    question: 'Why must the burette be rinsed with a few drops of the acid after washing it with distilled water?',
    options: [
      'To lubricate the stopcock valve so it turns smoothly',
      'To prevent residual water droplets from diluting the acid solution and altering its concentration',
      'To remove atmospheric carbon dioxide bubbles from the glass walls',
      'To neutralize any alkaline detergent left on the white tile',
    ],
    correctIndex: 1,
    explanation: 'Residual distilled water left inside the burette would dilute the acid solution, requiring a larger volume of acid to reach neutralization (yielding an erroneously high titre).',
    waecTip: 'WAEC Examiner Rule: Candidates lose 1-2 marks if they fail to specify that rinsing prevents solution dilution.',
  },
  {
    id: 'q2',
    question: 'How should the meniscus of a colorless solution (such as dilute hydrochloric acid) be read in the burette?',
    options: [
      'At the top of the curved liquid surface viewed from an elevated angle',
      'At the bottom of the curved concave meniscus with the eye strictly horizontal (eye-level)',
      'At the midpoint between the top and bottom curvature',
      'By estimating against the top line of the conical flask rim',
    ],
    correctIndex: 1,
    explanation: 'For clear or colorless liquids, surface tension creates a concave meniscus. Reading the bottom of this curve with your line of sight strictly perpendicular eliminates parallax error.',
    waecTip: 'Parallax error occurs when your eye is above or below the meniscus line, distorting the graduation reading.',
  },
  {
    id: 'q3',
    question: 'Why is the "Rough Trial" strictly excluded when computing the average titre (V_A)?',
    options: [
      'Because it is only a fast approximate trial to locate the general region of the endpoint',
      'Because the conical flask was not washed before starting the rough trial',
      'Because phenolphthalein indicator only works starting from the second trial',
      'Because the burette scale is not calibrated during the first run',
    ],
    correctIndex: 0,
    explanation: 'The rough trial is conducted rapidly to pinpoint where the color changes approximately. It almost always overshoots the true stoichiometric equivalence point.',
    waecTip: 'Never average the rough trial! In WAEC, including the rough trial results in an immediate deduction of method marks.',
  },
  {
    id: 'q4',
    question: 'What is the required concordance criterion for titration trials in the WAEC WASSCE marking scheme?',
    options: [
      'Readings must agree within ±0.50 cm³ of each other',
      'Readings must agree within ±0.10 cm³ of each other (or at most ±0.20 cm³)',
      'The initial readings must all start at exactly 0.00 cm³',
      'The final readings must be integers without decimal points',
    ],
    correctIndex: 1,
    explanation: 'Concordant titres are two or three titres whose values do not differ from one another by more than 0.10 cm³ (e.g. 24.10 and 24.20 cm³).',
    waecTip: 'Always record your burette readings to two decimal places (e.g. 24.10 cm³, not 24.1 cm). The second decimal place must end in 0 or 5.',
  },
  {
    id: 'q5',
    question: 'When phenolphthalein indicator is used, what is the exact visual sign of the true stoichiometric endpoint?',
    options: [
      'An immediate violent effervescence of gas bubbles',
      'A change to a dark purple or deep magenta colour that remains permanently',
      'A faint delicate pink colour that persists after 15–30 seconds of gentle swirling',
      'The solution turns cloudy and precipitates white crystals',
    ],
    correctIndex: 2,
    explanation: 'The equivalence point with phenolphthalein is marked by the very first drop that produces a permanent faint pink blush. Deep magenta indicates an overtitrated mixture.',
    waecTip: 'Always place a clean white tile under your conical flask to clearly detect this faint permanent pink blush against the white background.',
  },
];

export const AssessmentQuizView: React.FC<AssessmentQuizViewProps> = ({
  onSaveResult,
  savedResult,
}) => {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>(
    savedResult?.answers || {}
  );
  const [isSubmitted, setIsSubmitted] = useState<boolean>(!!savedResult);

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionIndex,
    }));
  };

  const handleSubmit = () => {
    let score = 0;
    WAEC_QUIZ_QUESTIONS.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        score++;
      }
    });

    const result: QuizResult = {
      score,
      total: WAEC_QUIZ_QUESTIONS.length,
      completedAt: Date.now(),
      answers: selectedAnswers,
    };

    setIsSubmitted(true);
    onSaveResult(result);
  };

  const handleRetake = () => {
    setSelectedAnswers({});
    setIsSubmitted(false);
  };

  const currentScore = WAEC_QUIZ_QUESTIONS.reduce((acc, q) => {
    return acc + (selectedAnswers[q.id] === q.correctIndex ? 1 : 0);
  }, 0);

  const allAnswered = WAEC_QUIZ_QUESTIONS.every((q) => selectedAnswers[q.id] !== undefined);

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 sm:py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            WAEC / NECO Chemistry Practical Assessment
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Volumetric Analysis Laboratory Methodology, Error Mitigation & Examiner Rubric
          </p>
        </div>

        {isSubmitted && (
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-[#D8E6FF] text-[#001B3F] px-4 py-2 rounded-xl font-bold text-sm">
              <Trophy className="w-4 h-4 text-[#1F5FBF]" />
              <span>Score: {currentScore} / {WAEC_QUIZ_QUESTIONS.length}</span>
            </div>
            <button
              onClick={handleRetake}
              className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl transition-colors shadow-2xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retake Quiz</span>
            </button>
          </div>
        )}
      </div>

      {/* Question Cards */}
      <div className="space-y-6">
        {WAEC_QUIZ_QUESTIONS.map((q, idx) => {
          const selected = selectedAnswers[q.id];
          const isCorrect = selected === q.correctIndex;
          const isAnswered = selected !== undefined;

          return (
            <div
              key={q.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4"
            >
              <div className="flex items-start gap-3">
                <span className="w-7 h-7 rounded-xl bg-slate-100 text-slate-800 font-bold text-xs flex items-center justify-center shrink-0">
                  {idx + 1}
                </span>
                <h2 className="text-sm sm:text-base font-semibold text-slate-900">
                  {q.question}
                </h2>
              </div>

              {/* Options */}
              <div className="grid grid-cols-1 gap-2.5 pt-1">
                {q.options.map((opt, optIdx) => {
                  const isThisSelected = selected === optIdx;
                  let optStyle = 'border-slate-200 bg-white hover:bg-slate-50 text-slate-800';

                  if (isSubmitted) {
                    if (optIdx === q.correctIndex) {
                      optStyle = 'border-emerald-300 bg-emerald-50 text-emerald-950 font-semibold';
                    } else if (isThisSelected && !isCorrect) {
                      optStyle = 'border-red-300 bg-red-50 text-red-950';
                    } else {
                      optStyle = 'border-slate-100 bg-slate-50/50 text-slate-400 opacity-70';
                    }
                  } else if (isThisSelected) {
                    optStyle = 'border-[#1F5FBF] bg-[#D8E6FF]/40 text-[#001B3F] font-semibold';
                  }

                  return (
                    <button
                      key={optIdx}
                      disabled={isSubmitted}
                      onClick={() => handleSelectOption(q.id, optIdx)}
                      className={`w-full min-h-[48px] px-4 py-3 rounded-xl border text-left text-xs sm:text-sm transition-all flex items-center justify-between gap-3 ${optStyle}`}
                    >
                      <span>{opt}</span>
                      {isSubmitted && optIdx === q.correctIndex && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      )}
                      {isSubmitted && isThisSelected && !isCorrect && (
                        <XCircle className="w-4 h-4 text-red-600 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Diagnostic Feedback upon submission */}
              {isSubmitted && (
                <div className={`p-4 rounded-xl text-xs space-y-2 border ${
                  isCorrect ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900' : 'bg-amber-50/60 border-amber-200 text-amber-950'
                }`}>
                  <p className="font-semibold">{q.explanation}</p>
                  <p className="text-[11px] text-slate-600 italic">💡 {q.waecTip}</p>
                </div>
              )}

            </div>
          );
        })}
      </div>

      {/* Submit Button */}
      {!isSubmitted && (
        <div className="flex justify-end pt-2 pb-8">
          <button
            onClick={handleSubmit}
            disabled={!allAnswered}
            className="min-h-[48px] px-6 py-3 bg-[#1F5FBF] hover:bg-[#154694] disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-bold rounded-xl shadow-xs transition-colors flex items-center gap-2"
          >
            <span>Submit Quiz for Grading</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

    </div>
  );
};
