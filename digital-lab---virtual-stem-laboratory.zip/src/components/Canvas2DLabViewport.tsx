/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { TitrationState } from '../types/lab.ts';

interface Canvas2DLabViewportProps {
  state: TitrationState;
  cameraPreset: 'overview' | 'burette' | 'flask';
}

export const Canvas2DLabViewport: React.FC<Canvas2DLabViewportProps> = ({
  state,
  cameraPreset,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef(state);
  const presetRef = useRef(cameraPreset);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    presetRef.current = cameraPreset;
  }, [cameraPreset]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let swirlTime = 0;
    let dropProgress = 0;

    const render = () => {
      animId = requestAnimationFrame(render);
      const width = canvas.width;
      const height = canvas.height;
      const s = stateRef.current;
      const preset = presetRef.current;

      ctx.clearRect(0, 0, width, height);

      // Background graph grid styling
      ctx.fillStyle = '#F8FAFC';
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = '#E2E8F0';
      ctx.lineWidth = 1;
      const gridSize = 24;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      ctx.save();

      // Camera Preset Transforms
      if (preset === 'burette') {
        ctx.translate(width * 0.1, -height * 0.1);
        ctx.scale(1.4, 1.4);
      } else if (preset === 'flask') {
        ctx.translate(width * 0.1, -height * 0.45);
        ctx.scale(1.5, 1.5);
      }

      const centerX = width * 0.46;
      const benchY = height * 0.85;

      // 1. Lab Bench
      ctx.fillStyle = '#E2E8F0';
      ctx.fillRect(width * 0.05, benchY, width * 0.9, height * 0.12);
      ctx.fillStyle = '#CBD5E1';
      ctx.fillRect(width * 0.05, benchY, width * 0.9, 4);

      // 2. Retort Stand Base
      const standBaseW = 180;
      const standBaseH = 16;
      ctx.fillStyle = '#334155';
      ctx.beginPath();
      ctx.roundRect(centerX - 130, benchY - standBaseH, standBaseW, standBaseH, [4, 4, 0, 0]);
      ctx.fill();

      // White Contrast Porcelain Tile
      const tileW = 140;
      const tileH = 8;
      ctx.fillStyle = '#FFFFFF';
      ctx.strokeStyle = '#CBD5E1';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.roundRect(centerX - 70, benchY - standBaseH - tileH, tileW, tileH, 2);
      ctx.fill();
      ctx.stroke();

      // Retort Vertical Rod
      const rodX = centerX - 100;
      const rodTopY = height * 0.08;
      ctx.fillStyle = '#64748B';
      ctx.fillRect(rodX, rodTopY, 10, benchY - standBaseH - rodTopY);

      // Clamp Bosshead & Arms
      const clampY = height * 0.38;
      ctx.fillStyle = '#1E293B';
      ctx.fillRect(rodX - 4, clampY - 10, 18, 20);

      ctx.fillStyle = '#94A3B8';
      ctx.fillRect(rodX + 10, clampY - 4, centerX - rodX - 10, 8);

      // Clamp fingers
      ctx.fillStyle = '#334155';
      ctx.fillRect(centerX - 16, clampY - 14, 32, 28);

      // 3. 50 mL Burette
      const buretteW = 22;
      const buretteTopY = height * 0.12;
      const buretteBottomY = height * 0.58;
      const buretteH = buretteBottomY - buretteTopY;
      const buretteX = centerX - buretteW / 2;

      // Burette Liquid (Acid)
      // Height decreases as dispensedVolume increases (0 to 50 mL)
      const liquidFraction = Math.max(0.02, (50.0 - s.dispensedVolume) / 50.0);
      const liquidH = buretteH * liquidFraction;
      const liquidTopY = buretteTopY + (buretteH - liquidH);

      ctx.fillStyle = '#E0F2FE';
      ctx.fillRect(buretteX + 2, liquidTopY, buretteW - 4, liquidH);

      // Meniscus Curve
      ctx.fillStyle = '#38BDF8';
      ctx.beginPath();
      ctx.ellipse(centerX, liquidTopY, (buretteW - 4) / 2, 3, 0, 0, Math.PI * 2);
      ctx.fill();

      // Burette Glass Tube Outline
      ctx.strokeStyle = '#0284C7';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(buretteX, buretteTopY, buretteW, buretteH);

      // Burette Graduations and Numbers
      ctx.fillStyle = '#0F172A';
      ctx.font = '10px "Noto Sans", sans-serif';
      ctx.textAlign = 'right';

      for (let i = 0; i <= 50; i += 5) {
        const lineY = buretteTopY + (i / 50) * buretteH;
        ctx.fillRect(buretteX + buretteW - 8, lineY, 8, 1.5);
        ctx.fillText(`${i}`, buretteX - 4, lineY + 3);
      }

      // Stopcock
      const stopcockY = buretteBottomY + 8;
      ctx.fillStyle = '#EF4444'; // Red PTFE valve
      ctx.fillRect(centerX - 14, stopcockY - 5, 28, 10);
      ctx.fillStyle = '#B91C1C';
      ctx.fillRect(centerX - 18, stopcockY - 8, 6, 16);

      // Jet Tip
      ctx.beginPath();
      ctx.moveTo(centerX - 4, stopcockY + 5);
      ctx.lineTo(centerX + 4, stopcockY + 5);
      ctx.lineTo(centerX + 1.5, stopcockY + 28);
      ctx.lineTo(centerX - 1.5, stopcockY + 28);
      ctx.closePath();
      ctx.fillStyle = '#BAE6FD';
      ctx.fill();
      ctx.strokeStyle = '#0284C7';
      ctx.lineWidth = 1;
      ctx.stroke();

      // 4. Falling Droplet Animation
      if (s.lastAddedDelta > 0) {
        dropProgress = (dropProgress + 0.08) % 1;
        const dropY = stopcockY + 28 + dropProgress * 40;
        ctx.fillStyle = '#0284C7';
        ctx.beginPath();
        ctx.ellipse(centerX, dropY, 2.5, 4, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // 5. Conical Flask (Erlenmeyer)
      const flaskBaseY = benchY - standBaseH - tileH;
      const flaskH = 110;
      const flaskTopY = flaskBaseY - flaskH;
      const flaskNeckW = 32;
      const flaskBottomW = 130;

      ctx.save();
      if (s.isSwirling) {
        swirlTime += 0.2;
        const swirlOffset = Math.sin(swirlTime) * 8;
        ctx.translate(swirlOffset, 0);
      }

      // Flask Path
      ctx.beginPath();
      ctx.moveTo(centerX - flaskNeckW / 2, flaskTopY);
      ctx.lineTo(centerX + flaskNeckW / 2, flaskTopY);
      ctx.lineTo(centerX + flaskNeckW / 2, flaskTopY + 30);
      ctx.lineTo(centerX + flaskBottomW / 2, flaskBaseY - 6);
      ctx.quadraticCurveTo(centerX + flaskBottomW / 2, flaskBaseY, centerX + flaskBottomW / 2 - 8, flaskBaseY);
      ctx.lineTo(centerX - flaskBottomW / 2 + 8, flaskBaseY);
      ctx.quadraticCurveTo(centerX - flaskBottomW / 2, flaskBaseY, centerX - flaskBottomW / 2, flaskBaseY - 6);
      ctx.lineTo(centerX - flaskNeckW / 2, flaskTopY + 30);
      ctx.closePath();

      // Clip and fill Flask Liquid
      ctx.save();
      ctx.clip();

      const liquidLevelY = flaskBaseY - 45; // ~25 mL aliquot
      ctx.fillStyle = s.colorHex;
      ctx.fillRect(centerX - flaskBottomW / 2, liquidLevelY, flaskBottomW, flaskBaseY - liquidLevelY);

      // Liquid Surface meniscus
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.beginPath();
      ctx.ellipse(centerX, liquidLevelY, 44, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Flask Glass Contour Outline
      ctx.strokeStyle = '#0284C7';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Lip Flange
      ctx.fillStyle = '#BAE6FD';
      ctx.strokeRect(centerX - flaskNeckW / 2 - 3, flaskTopY - 4, flaskNeckW + 6, 4);

      ctx.restore(); // restore swirl

      // 6. Magnified Meniscus Eye-Level Reader Loupe (Top right inset)
      // Designed specifically to teach WAEC students how to avoid parallax error by reading the bottom of the meniscus
      const loupeX = width - 110;
      const loupeY = 85;
      const loupeR = 54;

      ctx.save();
      ctx.beginPath();
      ctx.arc(loupeX, loupeY, loupeR, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#1F5FBF';
      ctx.stroke();
      ctx.clip();

      // Loupe Background
      ctx.fillStyle = '#F0F9FF';
      ctx.fillRect(loupeX - loupeR, loupeY - loupeR, loupeR * 2, loupeR * 2);

      // Loupe Liquid Meniscus (curved downward)
      ctx.fillStyle = '#BAE6FD';
      ctx.fillRect(loupeX - loupeR, loupeY + 2, loupeR * 2, loupeR);

      ctx.beginPath();
      ctx.arc(loupeX, loupeY - 14, 38, 0, Math.PI, false);
      ctx.fillStyle = '#F0F9FF';
      ctx.fill();

      // Eye-level crosshair guideline (red dashed line)
      ctx.strokeStyle = '#EF4444';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 2]);
      ctx.beginPath();
      ctx.moveTo(loupeX - loupeR, loupeY + 2);
      ctx.lineTo(loupeX + loupeR, loupeY + 2);
      ctx.stroke();
      ctx.setLineDash([]);

      // Reading Label inside Loupe
      ctx.fillStyle = '#0F172A';
      ctx.font = 'bold 12px "Noto Sans", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${s.dispensedVolume.toFixed(2)} mL`, loupeX, loupeY - 26);

      ctx.restore();

      // Loupe Title
      ctx.fillStyle = '#475569';
      ctx.font = '10px "Noto Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Meniscus (Eye-Level)', loupeX, loupeY + loupeR + 14);

      ctx.restore(); // restore preset transform
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <div className="relative w-full h-full min-h-[380px] sm:min-h-[440px] bg-slate-50 overflow-hidden select-none">
      <canvas
        ref={canvasRef}
        width={720}
        height={480}
        className="w-full h-full object-contain"
      />
    </div>
  );
};
