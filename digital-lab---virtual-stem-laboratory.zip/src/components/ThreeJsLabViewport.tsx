/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { TitrationState } from '../types/lab.ts';

interface ThreeJsLabViewportProps {
  state: TitrationState;
  cameraPreset: 'overview' | 'burette' | 'flask';
  onFallbackTo2D: () => void;
}

// Pre-allocated scratch math helpers outside animation loop to prevent GC thrashing
const _targetPos = new THREE.Vector3();
const _targetLookAt = new THREE.Vector3();
const _currentLookAt = new THREE.Vector3(0, -0.1, 0);

export const ThreeJsLabViewport: React.FC<ThreeJsLabViewportProps> = ({
  state,
  cameraPreset,
  onFallbackTo2D,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef(state);
  const cameraPresetRef = useRef(cameraPreset);
  const [fpsWarning, setFpsWarning] = useState<string | null>(null);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    cameraPresetRef.current = cameraPreset;
  }, [cameraPreset]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let animationFrameId: number;
    let renderer: THREE.WebGLRenderer | null = null;
    let scene: THREE.Scene | null = null;
    let camera: THREE.PerspectiveCamera | null = null;

    // Check WebGL availability safely
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        onFallbackTo2D();
        return;
      }
    } catch {
      onFallbackTo2D();
      return;
    }

    try {
      const width = container.clientWidth || 800;
      const height = container.clientHeight || 550;

      scene = new THREE.Scene();
      const bgColor = new THREE.Color(0xF5F7FB);
      scene.background = bgColor;
      scene.fog = new THREE.Fog(0xF5F7FB, 8, 25);

      camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 50);
      camera.position.set(0, 0.2, 4.0);

      renderer = new THREE.WebGLRenderer({
        antialias: true,
        powerPreference: 'high-performance',
        alpha: false,
      });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.1;
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;

      container.appendChild(renderer.domElement);

      // Studio Environment map via RoomEnvironment
      const pmrem = new THREE.PMREMGenerator(renderer);
      scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      pmrem.dispose();

      // Studio Lighting: Warm directional key light, Cool hemisphere fill
      const hemiLight = new THREE.HemisphereLight(0xDBEAFE, 0xF1F5F9, 0.85);
      scene.add(hemiLight);

      const dirLight = new THREE.DirectionalLight(0xFFFBEB, 1.3);
      dirLight.position.set(2.8, 4.5, 3.2);
      dirLight.castShadow = true;
      dirLight.shadow.mapSize.width = 1024;
      dirLight.shadow.mapSize.height = 1024;
      dirLight.shadow.camera.near = 0.5;
      dirLight.shadow.camera.far = 10;
      dirLight.shadow.bias = -0.0005;
      const d = 1.8;
      dirLight.shadow.camera.left = -d;
      dirLight.shadow.camera.right = d;
      dirLight.shadow.camera.top = d;
      dirLight.shadow.camera.bottom = -d;
      scene.add(dirLight);

      const rimLight = new THREE.DirectionalLight(0x93C5FD, 0.5);
      rimLight.position.set(-2.4, 2.0, -2.2);
      scene.add(rimLight);

      // Laboratory Apparatus Assembly Group
      const labGroup = new THREE.Group();
      scene.add(labGroup);

      // --- 1. Bench & Contact Shadow ---
      const benchGeo = new THREE.BoxGeometry(4.2, 0.1, 2.4);
      const benchMat = new THREE.MeshStandardMaterial({
        color: 0xE2E8F0,
        roughness: 0.4,
        metalness: 0.05,
      });
      const bench = new THREE.Mesh(benchGeo, benchMat);
      bench.position.set(0, -0.96, 0);
      bench.receiveShadow = true;
      labGroup.add(bench);

      // Soft contact shadow plane beneath apparatus
      const shadowGeo = new THREE.PlaneGeometry(1.6, 1.4);
      const shadowCanvas = document.createElement('canvas');
      shadowCanvas.width = 256;
      shadowCanvas.height = 256;
      const sctx = shadowCanvas.getContext('2d');
      if (sctx) {
        const grad = sctx.createRadialGradient(128, 128, 10, 128, 128, 120);
        grad.addColorStop(0, 'rgba(15, 23, 42, 0.35)');
        grad.addColorStop(0.6, 'rgba(15, 23, 42, 0.12)');
        grad.addColorStop(1, 'rgba(15, 23, 42, 0)');
        sctx.fillStyle = grad;
        sctx.fillRect(0, 0, 256, 256);
      }
      const shadowTex = new THREE.CanvasTexture(shadowCanvas);
      const shadowMat = new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        depthWrite: false,
      });
      const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
      shadowPlane.rotation.x = -Math.PI / 2;
      shadowPlane.position.set(-0.1, -0.908, 0);
      labGroup.add(shadowPlane);

      // --- 2. Retort Stand (3-Part Procedural Group) ---
      // Heavy iron stand base
      const baseGeo = new THREE.BoxGeometry(0.72, 0.05, 1.15);
      const baseMat = new THREE.MeshStandardMaterial({
        color: 0x334155,
        roughness: 0.65,
        metalness: 0.85,
      });
      const standBase = new THREE.Mesh(baseGeo, baseMat);
      standBase.position.set(-0.25, -0.88, 0);
      standBase.castShadow = true;
      standBase.receiveShadow = true;
      labGroup.add(standBase);

      // Vertical support rod
      const rodGeo = new THREE.CylinderGeometry(0.016, 0.016, 2.45, 24);
      const metalMat = new THREE.MeshStandardMaterial({
        color: 0x94A3B8,
        roughness: 0.22,
        metalness: 0.92,
      });
      const rod = new THREE.Mesh(rodGeo, metalMat);
      rod.position.set(-0.45, 0.32, -0.3);
      rod.castShadow = true;
      labGroup.add(rod);

      // Clamp Bosshead, Thumbscrew & Clamp Arm
      const bossheadGeo = new THREE.BoxGeometry(0.065, 0.065, 0.085);
      const darkMetalMat = new THREE.MeshStandardMaterial({ color: 0x1E293B, roughness: 0.45, metalness: 0.8 });
      const bosshead = new THREE.Mesh(bossheadGeo, darkMetalMat);
      bosshead.position.set(-0.45, 0.52, -0.3);
      labGroup.add(bosshead);

      const clampArmGeo = new THREE.CylinderGeometry(0.009, 0.009, 0.46, 16);
      clampArmGeo.rotateZ(Math.PI / 2);
      const clampArm = new THREE.Mesh(clampArmGeo, metalMat);
      clampArm.position.set(-0.24, 0.52, -0.3);
      labGroup.add(clampArm);

      // Clamp Fingers
      const fingerGeo = new THREE.TorusGeometry(0.046, 0.008, 12, 24, Math.PI * 1.4);
      fingerGeo.rotateX(Math.PI / 2);
      const clampFingers = new THREE.Mesh(fingerGeo, darkMetalMat);
      clampFingers.position.set(0, 0.52, -0.3);
      labGroup.add(clampFingers);

      // White Porcelain Contrast Tile
      const tileGeo = new THREE.BoxGeometry(0.5, 0.02, 0.5);
      const tileMat = new THREE.MeshStandardMaterial({
        color: 0xFFFFFF,
        roughness: 0.08,
        metalness: 0.0,
      });
      const whiteTile = new THREE.Mesh(tileGeo, tileMat);
      whiteTile.position.set(0, -0.84, 0);
      whiteTile.receiveShadow = true;
      labGroup.add(whiteTile);

      // --- 3. 50 mL Glass Burette (Procedural Glassware) ---
      const buretteLength = 1.68;
      const buretteOuterRadius = 0.038;
      const buretteInnerRadius = 0.032;

      const buretteGeo = new THREE.CylinderGeometry(buretteOuterRadius, buretteOuterRadius, buretteLength, 32, 1, true);
      const glassMat = new THREE.MeshPhysicalMaterial({
        color: 0xFFFFFF,
        transmission: 0.95,
        opacity: 1,
        transparent: true,
        roughness: 0.04,
        ior: 1.52,
        thickness: 0.07,
        specularIntensity: 1.0,
        depthWrite: false,
      });
      const burette = new THREE.Mesh(buretteGeo, glassMat);
      burette.position.set(0, 0.54, 0);
      labGroup.add(burette);

      // Procedural Canvas Graduation Markings
      const gradCanvas = document.createElement('canvas');
      gradCanvas.width = 128;
      gradCanvas.height = 1024;
      const gctx = gradCanvas.getContext('2d');
      if (gctx) {
        gctx.clearRect(0, 0, 128, 1024);
        gctx.fillStyle = '#0F172A';
        gctx.font = 'bold 20px "Noto Sans", sans-serif';
        gctx.textAlign = 'right';

        for (let i = 0; i <= 50; i++) {
          const y = (i / 50) * 980 + 20;
          if (i % 5 === 0) {
            gctx.fillRect(78, y, 42, 3);
            gctx.fillText(`${i}`, 70, y + 7);
          } else {
            gctx.fillRect(94, y, 26, 2);
          }
        }
      }
      const gradTex = new THREE.CanvasTexture(gradCanvas);
      gradTex.colorSpace = THREE.SRGBColorSpace;
      gradTex.anisotropy = renderer.capabilities.getMaxAnisotropy();
      const gradMat = new THREE.MeshBasicMaterial({
        map: gradTex,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
      });
      const gradCylinder = new THREE.Mesh(
        new THREE.CylinderGeometry(buretteOuterRadius + 0.001, buretteOuterRadius + 0.001, buretteLength, 32, 1, true),
        gradMat
      );
      gradCylinder.position.set(0, 0.54, 0);
      labGroup.add(gradCylinder);

      // Stopcock Valve & Handle
      const valveKeyGeo = new THREE.CylinderGeometry(0.018, 0.018, 0.14, 16);
      valveKeyGeo.rotateZ(Math.PI / 2);
      const valveHandleGeo = new THREE.BoxGeometry(0.12, 0.024, 0.035);
      const teflonMat = new THREE.MeshStandardMaterial({ color: 0xDC2626, roughness: 0.35, metalness: 0.1 });
      const valveGroup = new THREE.Group();
      valveGroup.add(new THREE.Mesh(valveKeyGeo, teflonMat));
      const handleMesh = new THREE.Mesh(valveHandleGeo, teflonMat);
      handleMesh.position.set(0.05, 0, 0);
      valveGroup.add(handleMesh);
      valveGroup.position.set(0, -0.32, 0);
      labGroup.add(valveGroup);

      // Jet Tip
      const tipGeo = new THREE.CylinderGeometry(0.02, 0.006, 0.14, 16);
      const tip = new THREE.Mesh(tipGeo, glassMat);
      tip.position.set(0, -0.42, 0);
      labGroup.add(tip);

      // Acid Liquid Column inside Burette
      const acidLiquidMat = new THREE.MeshPhysicalMaterial({
        color: 0xE0F2FE,
        transmission: 0.88,
        transparent: true,
        roughness: 0.06,
        ior: 1.33,
        depthWrite: false,
      });
      const acidColumnGeo = new THREE.CylinderGeometry(buretteInnerRadius, buretteInnerRadius, buretteLength, 24);
      const acidColumn = new THREE.Mesh(acidColumnGeo, acidLiquidMat);
      acidColumn.position.set(0, 0.54, 0);
      labGroup.add(acidColumn);

      // Meniscus Disc at top of titrant column
      const meniscusGeo = new THREE.CylinderGeometry(buretteInnerRadius, buretteInnerRadius, 0.006, 24);
      const meniscusMat = new THREE.MeshStandardMaterial({
        color: 0x38BDF8,
        roughness: 0.12,
        transparent: true,
        opacity: 0.8,
      });
      const meniscusMesh = new THREE.Mesh(meniscusGeo, meniscusMat);
      meniscusMesh.position.set(0, 0.54 + buretteLength / 2, 0);
      labGroup.add(meniscusMesh);

      // --- 4. 250 mL Conical Erlenmeyer Flask ---
      const flaskGroup = new THREE.Group();
      flaskGroup.position.set(0, -0.83, 0);
      labGroup.add(flaskGroup);

      const flaskPoints: THREE.Vector2[] = [];
      flaskPoints.push(new THREE.Vector2(0, 0.01));
      flaskPoints.push(new THREE.Vector2(0.24, 0.01));
      flaskPoints.push(new THREE.Vector2(0.22, 0.06));
      flaskPoints.push(new THREE.Vector2(0.08, 0.28));
      flaskPoints.push(new THREE.Vector2(0.065, 0.38));
      flaskPoints.push(new THREE.Vector2(0.075, 0.40));
      const flaskGeo = new THREE.LatheGeometry(flaskPoints, 36);
      const flaskMesh = new THREE.Mesh(flaskGeo, glassMat);
      flaskMesh.castShadow = true;
      flaskGroup.add(flaskMesh);

      // Flask Liquid with dynamic colorimetry
      const flaskLiquidPoints: THREE.Vector2[] = [];
      flaskLiquidPoints.push(new THREE.Vector2(0, 0.015));
      flaskLiquidPoints.push(new THREE.Vector2(0.22, 0.015));
      flaskLiquidPoints.push(new THREE.Vector2(0.20, 0.06));
      flaskLiquidPoints.push(new THREE.Vector2(0.14, 0.16));
      flaskLiquidPoints.push(new THREE.Vector2(0, 0.16));
      const flaskLiquidGeo = new THREE.LatheGeometry(flaskLiquidPoints, 32);
      const flaskLiquidMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(stateRef.current.colorHex),
        roughness: 0.12,
        metalness: 0.0,
        transparent: true,
        opacity: 0.9,
      });
      const flaskLiquidMesh = new THREE.Mesh(flaskLiquidGeo, flaskLiquidMat);
      flaskGroup.add(flaskLiquidMesh);

      // Falling droplet particle
      const dropGeo = new THREE.SphereGeometry(0.012, 12, 12);
      dropGeo.scale(1, 1.8, 1);
      const dropMesh = new THREE.Mesh(dropGeo, acidLiquidMat);
      dropMesh.position.set(0, -0.48, 0);
      dropMesh.visible = false;
      labGroup.add(dropMesh);

      // Camera preset coordinates
      const cameraTargets = {
        overview: { pos: new THREE.Vector3(0, 0.15, 3.9), lookAt: new THREE.Vector3(0, -0.1, 0) },
        burette: { pos: new THREE.Vector3(0.05, 0.52, 1.55), lookAt: new THREE.Vector3(0, 0.52, 0) },
        flask: { pos: new THREE.Vector3(0, -0.66, 1.45), lookAt: new THREE.Vector3(0, -0.72, 0) },
      };

      // Animation & Lossless Loop
      let lastTime = performance.now();
      let lowFpsCount = 0;
      let swirlPhase = 0;
      let dropPhase = 0;

      const animate = (time: number) => {
        if (!renderer || !camera || !scene) return;
        animationFrameId = requestAnimationFrame(animate);

        const delta = Math.min((time - lastTime) / 1000, 0.1);
        lastTime = time;

        // Exponential damping factor: 1 - Math.exp(-k * delta)
        const dampFactor = 1 - Math.exp(-6 * delta);

        // Performance watchdog
        if (delta > 0.055) {
          lowFpsCount++;
          if (lowFpsCount > 35) {
            setFpsWarning('Device GPU running low frame-rate. Switched to 2D Mode.');
            onFallbackTo2D();
            return;
          }
        } else {
          lowFpsCount = Math.max(0, lowFpsCount - 1);
        }

        const currentState = stateRef.current;
        const currentPreset = cameraPresetRef.current;

        // Smooth Camera Presets transition using exponential damping
        const target = cameraTargets[currentPreset] || cameraTargets.overview;
        camera.position.lerp(target.pos, dampFactor);
        _currentLookAt.lerp(target.lookAt, dampFactor);
        camera.lookAt(_currentLookAt);

        // Burette Column height update
        const fillFraction = Math.max(0.01, (50.0 - currentState.dispensedVolume) / 50.0);
        const colHeight = buretteLength * fillFraction;
        acidColumn.scale.set(1, fillFraction, 1);
        const topOfBurette = 0.54 + buretteLength / 2;
        acidColumn.position.y = topOfBurette - colHeight / 2;
        meniscusMesh.position.y = topOfBurette - (buretteLength * (1 - fillFraction));

        // Update liquid color
        flaskLiquidMat.color.set(currentState.colorHex);

        // Kinetic swirling oscillation
        if (currentState.isSwirling) {
          swirlPhase += delta * 15;
          flaskGroup.rotation.z = Math.sin(swirlPhase) * 0.08;
          flaskGroup.rotation.x = Math.cos(swirlPhase) * 0.08;
          flaskLiquidMesh.rotation.y += delta * 8;
        } else {
          flaskGroup.rotation.z *= (1 - dampFactor);
          flaskGroup.rotation.x *= (1 - dampFactor);
        }

        // Falling drop animation
        if (currentState.lastAddedDelta > 0 && dropPhase < 1.0) {
          dropPhase += delta * 4;
          dropMesh.visible = true;
          dropMesh.position.y = THREE.MathUtils.lerp(-0.48, -0.74, dropPhase);
        } else {
          dropMesh.visible = false;
          if (currentState.lastAddedDelta === 0) {
            dropPhase = 0;
          }
        }

        // Valve rotation
        if (currentState.lastAddedDelta > 0) {
          valveGroup.rotation.x = THREE.MathUtils.lerp(valveGroup.rotation.x, Math.PI / 4, dampFactor * 3);
        } else {
          valveGroup.rotation.x = THREE.MathUtils.lerp(valveGroup.rotation.x, 0, dampFactor * 2);
        }

        renderer.render(scene, camera);
      };

      animationFrameId = requestAnimationFrame(animate);

      const handleResize = () => {
        if (!container || !renderer || !camera) return;
        const newW = container.clientWidth;
        const newH = container.clientHeight;
        camera.aspect = newW / newH;
        camera.updateProjectionMatrix();
        renderer.setSize(newW, newH);
      };

      window.addEventListener('resize', handleResize);

      const canvasElem = renderer.domElement;
      const handleContextLost = (e: Event) => {
        e.preventDefault();
        console.warn('WebGL context lost. Falling back to 2D.');
        onFallbackTo2D();
      };
      canvasElem.addEventListener('webglcontextlost', handleContextLost);

      return () => {
        cancelAnimationFrame(animationFrameId);
        window.removeEventListener('resize', handleResize);
        if (canvasElem) {
          canvasElem.removeEventListener('webglcontextlost', handleContextLost);
        }
        if (renderer) {
          renderer.dispose();
          if (container && renderer.domElement.parentNode === container) {
            container.removeChild(renderer.domElement);
          }
        }
      };
    } catch (err) {
      console.error('Three.js setup error:', err);
      onFallbackTo2D();
    }
  }, [onFallbackTo2D]);

  return (
    <div className="relative w-full h-full min-h-[400px] sm:min-h-[460px] bg-slate-50 overflow-hidden select-none">
      <div ref={containerRef} className="w-full h-full" />

      {fpsWarning && (
        <div className="absolute top-3 left-3 bg-amber-500/90 text-white text-xs px-3 py-1.5 rounded-xl shadow-xs">
          {fpsWarning}
        </div>
      )}
    </div>
  );
};
