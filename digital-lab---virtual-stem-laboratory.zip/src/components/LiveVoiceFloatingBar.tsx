/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { LiveAudioClient } from '../services/liveAudioClient.ts';
import { Mic, MicOff, PhoneCall, PhoneOff, Radio, Sparkles, Volume2, X } from 'lucide-react';

interface LiveVoiceFloatingBarProps {
  onClose: () => void;
  isOpen: boolean;
}

export const LiveVoiceFloatingBar: React.FC<LiveVoiceFloatingBarProps> = ({ onClose, isOpen }) => {
  const [status, setStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'speaking' | 'listening'>('disconnected');
  const [isMuted, setIsMuted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [transcriptStream, setTranscriptStream] = useState<string>('');
  const [liveClient, setLiveClient] = useState<LiveAudioClient | null>(null);

  useEffect(() => {
    if (!isOpen) {
      if (liveClient) {
        liveClient.disconnect();
        setLiveClient(null);
      }
      return;
    }

    const client = new LiveAudioClient({
      onStatusChange: (newStatus) => {
        setStatus(newStatus);
        if (newStatus === 'connected' || newStatus === 'listening') {
          setErrorMessage(null);
        }
      },
      onError: (err) => {
        setErrorMessage(err);
      },
      onTranscriptChunk: (chunk) => {
        setTranscriptStream((prev) => (prev + ' ' + chunk).slice(-180));
      },
    });

    setLiveClient(client);
    client.connect();

    return () => {
      client.disconnect();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const toggleMute = () => {
    if (liveClient) {
      const nextMute = !isMuted;
      setIsMuted(nextMute);
      liveClient.setMuted(nextMute);
    }
  };

  return (
    <div className="fixed top-20 right-4 z-40 max-w-sm w-[90vw] sm:w-80 bg-slate-900 border border-slate-700/80 rounded-2xl p-3.5 text-white shadow-2xl transition-all">
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
          <span className="font-semibold text-xs tracking-tight">
            Gemini 3.8 Live (Voice Conversation)
          </span>
        </div>

        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          aria-label="Close voice session"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="py-2.5 space-y-2">
        {/* Status bar */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400">Connection:</span>
          <span className="font-mono text-[11px] uppercase font-bold text-cyan-300">
            {status}
          </span>
        </div>

        {/* Live Audio Visualizer / Animation */}
        <div className="flex items-center justify-center gap-1.5 py-2 h-8">
          {[40, 75, 55, 90, 60, 80, 45].map((height, i) => (
            <div
              key={i}
              className={`w-1 rounded-full transition-all duration-150 ${
                status === 'speaking'
                  ? 'bg-cyan-400'
                  : status === 'listening'
                  ? 'bg-emerald-400'
                  : 'bg-slate-700'
              }`}
              style={{
                height: status === 'speaking' || status === 'listening' ? `${height}%` : '20%',
              }}
            />
          ))}
        </div>

        {/* Transcript stream or hint */}
        <p className="text-[11px] text-slate-300 min-h-[36px] bg-slate-800/80 p-2 rounded-xl leading-relaxed font-sans">
          {transcriptStream || (status === 'listening' ? 'Listening to your microphone... ask a titration question!' : 'Connecting to Live API...')}
        </p>

        {errorMessage && (
          <p className="text-[10px] text-red-400 bg-red-950/50 p-1.5 rounded-lg border border-red-800/50">
            {errorMessage}
          </p>
        )}
      </div>

      {/* Control Buttons */}
      <div className="flex items-center justify-between pt-1">
        <button
          onClick={toggleMute}
          disabled={status === 'disconnected'}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
            isMuted
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
          }`}
        >
          {isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
          <span>{isMuted ? 'Unmute' : 'Mute'}</span>
        </button>

        <button
          onClick={onClose}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors shadow-2xs"
        >
          <PhoneOff className="w-3.5 h-3.5" />
          <span>End Call</span>
        </button>
      </div>
    </div>
  );
};
