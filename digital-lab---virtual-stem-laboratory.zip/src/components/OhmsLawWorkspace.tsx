/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AcademicLevel } from '../types/lab.ts';
import { audioSpeechService } from '../services/audioSpeechService.ts';
import { CheckCircle2, Download, Gauge, Play, Power, RotateCcw, Zap } from 'lucide-react';

interface OhmsLawWorkspaceProps {
  level: AcademicLevel;
}

interface CircuitReading {
  id: string;
  rheostatOhms: number;
  currentAmps: number;
  voltageVolts: number;
}

export const OhmsLawWorkspace: React.FC<OhmsLawWorkspaceProps> = ({ level }) => {
  const [isSwitchClosed, setIsSwitchClosed] = useState(true);
  const [rheostatVal, setRheostatVal] = useState(10); // Ohms
  const fixedResistor = 5.0; // Ohms
  const batteryVoltage = 6.0; // Volts (4 x 1.5V dry cells)
  const [readings, setReadings] = useState<CircuitReading[]>([
    { id: '1', rheostatOhms: 25, currentAmps: 0.2, voltageVolts: 1.0 },
    { id: '2', rheostatOhms: 15, currentAmps: 0.3, voltageVolts: 1.5 },
  ]);

  // Compute circuit values
  const totalResistance = fixedResistor + rheostatVal;
  const current = isSwitchClosed ? Number((batteryVoltage / totalResistance).toFixed(3)) : 0;
  const voltage = isSwitchClosed ? Number((current * fixedResistor).toFixed(3)) : 0;

  const handleToggleSwitch = () => {
    setIsSwitchClosed(!isSwitchClosed);
    audioSpeechService.playDropSound();
  };

  const handleRecordDataPoint = () => {
    if (!isSwitchClosed) return;
    const newPoint: CircuitReading = {
      id: `${Date.now()}`,
      rheostatOhms: rheostatVal,
      currentAmps: current,
      voltageVolts: voltage,
    };
    setReadings([...readings, newPoint]);
    audioSpeechService.playEndpointChime();
  };

  // Slope calculation: R = Delta V / Delta I
  const calculateSlope = () => {
    if (readings.length < 2) return null;
    const sorted = [...readings].sort((a, b) => a.currentAmps - b.currentAmps);
    const p1 = sorted[0];
    const p2 = sorted[sorted.length - 1];
    const dV = p2.voltageVolts - p1.voltageVolts;
    const dI = p2.currentAmps - p1.currentAmps;
    if (Math.abs(dI) < 0.001) return null;
    return Number((dV / dI).toFixed(2));
  };

  const slopeResistance = calculateSlope();

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8 space-y-8">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Verification of Ohm's Law (V = IR)
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            WAEC Physics Paper 3 · Direct Current Circuit & Slope Resistance Determination
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleToggleSwitch}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-xs transition-all shadow-xs ${
              isSwitchClosed
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
            }`}
          >
            <Power className="w-4 h-4" />
            <span>Key {isSwitchClosed ? 'CLOSED (Active)' : 'OPEN (Off)'}</span>
          </button>
        </div>
      </div>

      {/* Circuit Schematic & Live Meters Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Interactive Circuit Board */}
        <div className="lg:col-span-2 bg-slate-900 rounded-3xl p-6 text-white shadow-md relative overflow-hidden flex flex-col justify-between min-h-[380px]">
          
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-mono">DC Bench Source: 6.0 V (4 × 1.5V Leclanché Cells)</span>
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-emerald-400 font-mono">
              Circuit {isSwitchClosed ? 'COMPLETE' : 'BROKEN'}
            </span>
          </div>

          {/* Meters Dial Layout */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
            
            {/* Ammeter Display */}
            <div className="bg-slate-800/90 rounded-2xl p-4 border border-slate-700 flex flex-col items-center justify-center space-y-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-400 uppercase tracking-wider font-semibold">
                <Gauge className="w-4 h-4 text-cyan-400" />
                <span>Ammeter (Current I)</span>
              </div>
              <div className="font-mono text-3xl sm:text-4xl font-bold text-cyan-400 tabular-nums">
                {current.toFixed(3)}
              </div>
              <span className="text-xs text-slate-400 font-mono">Amperes (A)</span>
            </div>

            {/* Voltmeter Display */}
            <div className="bg-slate-800/90 rounded-2xl p-4 border border-slate-700 flex flex-col items-center justify-center space-y-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-400 uppercase tracking-wider font-semibold">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Voltmeter (P.D. V)</span>
              </div>
              <div className="font-mono text-3xl sm:text-4xl font-bold text-amber-400 tabular-nums">
                {voltage.toFixed(3)}
              </div>
              <span className="text-xs text-slate-400 font-mono">Volts (V)</span>
            </div>

          </div>

          {/* Rheostat Slider Control */}
          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300">
                Variable Rheostat Resistance (Rh):
              </span>
              <span className="font-mono text-emerald-400 font-bold text-sm">
                {rheostatVal.toFixed(1)} Ω
              </span>
            </div>

            <input
              type="range"
              min="2"
              max="35"
              step="0.5"
              value={rheostatVal}
              onChange={(e) => setRheostatVal(parseFloat(e.target.value))}
              disabled={!isSwitchClosed}
              className="w-full accent-cyan-400 cursor-pointer h-2 bg-slate-700 rounded-lg"
            />
            
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>2.0 Ω (Max Current)</span>
              <span>Fixed Resistor R: 5.0 Ω</span>
              <span>35.0 Ω (Min Current)</span>
            </div>
          </div>

        </div>

        {/* Right Col: Record Reading & Slope deduction */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col justify-between shadow-xs space-y-4">
          
          <div className="space-y-3">
            <h2 className="text-base font-bold text-slate-900">
              Record Data Points
            </h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              Vary the rheostat slider to set 5 distinct current readings, and record corresponding potential differences (V).
            </p>

            <button
              onClick={handleRecordDataPoint}
              disabled={!isSwitchClosed}
              className="w-full min-h-[48px] px-4 py-2.5 bg-[#1F5FBF] hover:bg-[#154694] disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 active:scale-95"
            >
              <Zap className="w-4 h-4 fill-current" />
              <span>Record Point (V, I)</span>
            </button>
          </div>

          {/* Graph Slope deduction */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
            <span className="text-xs font-bold text-slate-700 block">
              WAEC Graph Deduction: Slope s = ΔV / ΔI
            </span>
            {slopeResistance !== null ? (
              <div className="space-y-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-xs text-slate-600">Calculated Resistance:</span>
                  <span className="text-lg font-bold font-mono text-[#00696B]">
                    {slopeResistance} Ω
                  </span>
                </div>
                <p className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Matches standard resistor (5.0 Ω) within ±2% error margin!</span>
                </p>
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic">
                Record at least 2 data points with different rheostat positions to evaluate the linear slope.
              </p>
            )}
          </div>

        </div>

      </div>

      {/* Physics Readings Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
          <span className="font-semibold text-slate-900 text-sm">
            Table of Values (Potential Difference vs Current)
          </span>
          <span className="text-xs text-slate-500 font-mono">
            {readings.length} Recorded Points
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm font-mono tabular-nums">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <th className="py-2.5 px-4 font-sans">#</th>
                <th className="py-2.5 px-4">Rheostat Rh (Ω)</th>
                <th className="py-2.5 px-4">Current I (A)</th>
                <th className="py-2.5 px-4">Voltage V (V)</th>
                <th className="py-2.5 px-4">Calculated V/I (Ω)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {readings.map((r, i) => (
                <tr key={r.id}>
                  <td className="py-2.5 px-4 font-sans text-slate-400">{i + 1}</td>
                  <td className="py-2.5 px-4 text-slate-700">{r.rheostatOhms.toFixed(1)}</td>
                  <td className="py-2.5 px-4 text-cyan-700 font-bold">{r.currentAmps.toFixed(3)}</td>
                  <td className="py-2.5 px-4 text-amber-700 font-bold">{r.voltageVolts.toFixed(3)}</td>
                  <td className="py-2.5 px-4 text-slate-900 font-semibold">
                    {(r.voltageVolts / r.currentAmps).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
