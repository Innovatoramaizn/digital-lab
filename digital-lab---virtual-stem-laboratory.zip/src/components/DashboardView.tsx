/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AcademicLevel, ExperimentManifest } from '../types/lab.ts';
import { storageService } from '../services/storageService.ts';
import { BookOpen, CheckCircle, Clock, Database, FlaskConical, Play, Sparkles, Trash2, Zap } from 'lucide-react';

interface DashboardViewProps {
  level: AcademicLevel;
  setLevel: (lvl: AcademicLevel) => void;
  onLaunchExperiment: (id: string) => void;
  activeExperimentId: string;
}

const EXPERIMENT_CATALOG: ExperimentManifest[] = [
  {
    id: 'titration-acid-base',
    title: 'Acid-Base Volumetric Titration (HCl vs NaOH)',
    subject: 'chemistry',
    paper: 'Paper 3 (Practical)',
    levels: ['secondary', 'tertiary'],
    curriculumTags: ['WAEC-CHEM-PRACTICAL', 'NECO-CHEM-3', 'CHM101-100L'],
    durationMinutes: 35,
    assetBudgetKB: 420,
    description: 'Determine the concentration of dilute hydrochloric acid using standardized sodium hydroxide with phenolphthalein indicator and concordant trials.',
    apparatusList: ['50 mL Glass Burette', '250 mL Conical Flask', '25 mL Pipette', 'Retort Stand & Clamp', 'White Porcelain Tile'],
    isAvailable: true,
  },
  {
    id: 'physics-ohms-law',
    title: "Verification of Ohm's Law & Circuit Analysis",
    subject: 'physics',
    paper: 'Paper 3 (Electricity)',
    levels: ['secondary', 'tertiary'],
    curriculumTags: ['WAEC-PHY-ELEC', 'NECO-PHY-3', 'PHY102-100L'],
    durationMinutes: 40,
    assetBudgetKB: 390,
    description: 'Investigate the relationship between potential difference (V) and current (I) across constantan wire to determine unknown resistance and internal resistance.',
    apparatusList: ['Ammeter (0-3A)', 'Voltmeter (0-5V)', 'Rheostat', 'Resistance Wire', 'Dry Cells & Key'],
    isAvailable: true,
  },
  {
    id: 'physics-pendulum',
    title: 'Simple Pendulum & Acceleration due to Gravity (g)',
    subject: 'physics',
    paper: 'Paper 3 (Mechanics)',
    levels: ['secondary', 'tertiary'],
    curriculumTags: ['WAEC-PHY-MECH', 'NECO-PHY-MECH'],
    durationMinutes: 30,
    assetBudgetKB: 350,
    description: 'Determine the acceleration due to gravity (g) in Lagos by plotting period squared (T²) against length (L) of an inextensible string.',
    apparatusList: ['Split Cork', 'Heavy Metal Bob', 'Stopwatch', 'Meter Rule', 'Retort Stand'],
    isAvailable: true,
  },
  {
    id: 'biology-food-tests',
    title: 'Qualitative Food Tests for Starch & Reducing Sugars',
    subject: 'biology',
    paper: 'Paper 3 (Biochemical)',
    levels: ['secondary'],
    curriculumTags: ['WAEC-BIO-FOOD', 'NECO-BIO-3'],
    durationMinutes: 25,
    assetBudgetKB: 310,
    description: 'Identify unknown food specimens using Iodine solution, Fehling’s A and B solutions with water bath heating, and Biuret reagent.',
    apparatusList: ['Test Tubes & Rack', 'Bunsen / Water Bath', 'Dropper Pipettes', 'Iodine Solution', "Fehling's Reagent"],
    isAvailable: true,
  },
];

export const DashboardView: React.FC<DashboardViewProps> = ({
  level,
  setLevel,
  onLaunchExperiment,
  activeExperimentId,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<'all' | 'chemistry' | 'physics' | 'biology'>('all');
  const [storageInfo, setStorageInfo] = useState(storageService.getStorageUsage());

  const filteredExperiments = EXPERIMENT_CATALOG.filter((exp) => {
    if (selectedSubject !== 'all' && exp.subject !== selectedSubject) return false;
    return exp.levels.includes(level);
  });

  const handleClearCache = () => {
    storageService.clearAllData();
    setStorageInfo(storageService.getStorageUsage());
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 sm:py-8 space-y-8">
      
      {/* Hero Quick-Resume Card */}
      <div className="bg-gradient-to-br from-[#1F5FBF] to-[#0D3B82] rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-3">
          
          <div className="flex items-center gap-2 text-blue-200 text-xs font-semibold uppercase tracking-wider">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Active Practical Session · Offline-Ready</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Acid-Base Titration (0.100 M HCl vs NaOH)
          </h1>

          <p className="text-xs sm:text-sm text-blue-100 leading-relaxed">
            WAEC Chemistry Paper 3 Syllabus. Practice pipette handling, burette dropwise titration, faint pink endpoint detection, and stoichiometric calculations.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onLaunchExperiment('titration-acid-base')}
              className="px-5 py-2.5 bg-white hover:bg-slate-100 text-[#1F5FBF] font-bold text-xs sm:text-sm rounded-xl transition-all shadow-xs flex items-center gap-2 active:scale-95"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Resume Workspace</span>
            </button>

            <span className="text-xs text-blue-200 font-mono">
              IndexedDB Cached · 0 MB data needed
            </span>
          </div>

        </div>

        {/* Decorative Apparatus Background Icon */}
        <FlaskConical className="absolute right-4 bottom-2 w-48 h-48 text-white/5 pointer-events-none" />
      </div>

      {/* Storage and Device Resource Manager */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700 shrink-0">
            <Database className="w-5 h-5 text-[#1F5FBF]" />
          </div>
          <div>
            <div className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-2">
              <span>Offline Device Storage Budget</span>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-semibold">
                100% Offline Functional
              </span>
            </div>
            <p className="text-xs text-slate-500">
              {storageInfo.usedKB} KB used across {storageInfo.experimentCount} preloaded syllabus packages (Budget: {storageInfo.totalBudgetKB} KB)
            </p>
          </div>
        </div>

        <button
          onClick={handleClearCache}
          className="text-xs font-semibold text-slate-600 hover:text-red-700 flex items-center gap-1.5 self-start sm:self-center transition-colors"
          title="Reset local student ledger and cached notes"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Reset Lab Cache</span>
        </button>
      </div>

      {/* Subject Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 self-start">
          {(['all', 'chemistry', 'physics', 'biology'] as const).map((sub) => (
            <button
              key={sub}
              onClick={() => setSelectedSubject(sub)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg capitalize transition-colors ${
                selectedSubject === sub
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {sub === 'all' ? 'All Subjects' : sub}
            </button>
          ))}
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Showing <strong className="text-slate-800">{filteredExperiments.length}</strong> practical labs aligned with {level === 'secondary' ? 'WAEC / NECO Senior Secondary' : 'NUC 100-Level University Benchmark'}
        </div>
      </div>

      {/* Experiments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filteredExperiments.map((exp) => {
          const isActive = activeExperimentId === exp.id;

          return (
            <div
              key={exp.id}
              className={`bg-white rounded-2xl border p-5 sm:p-6 transition-all hover:shadow-xs flex flex-col justify-between space-y-4 ${
                isActive ? 'border-[#1F5FBF] ring-2 ring-[#1F5FBF]/10' : 'border-slate-200'
              }`}
            >
              <div className="space-y-2.5">
                
                {/* Meta Header */}
                <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-[#1F5FBF] capitalize">
                    {exp.subject} · {exp.paper}
                  </span>
                  <div className="flex items-center gap-1 text-slate-500">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{exp.durationMinutes} mins</span>
                  </div>
                </div>

                {/* Title */}
                <h2 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight leading-snug">
                  {exp.title}
                </h2>

                {/* Description */}
                <p className="text-xs text-slate-600 leading-relaxed">
                  {exp.description}
                </p>

                {/* Curriculum tags */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[11px] text-slate-500 font-mono">
                  {exp.curriculumTags.map((tag) => (
                    <span key={tag} className="bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                      {tag}
                    </span>
                  ))}
                </div>

              </div>

              {/* Card Footer Action */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Offline Ready ({exp.assetBudgetKB} KB)</span>
                </span>

                <button
                  onClick={() => onLaunchExperiment(exp.id)}
                  className="px-4 py-2 bg-[#1F5FBF] hover:bg-[#154694] text-white text-xs font-bold rounded-xl transition-colors shadow-2xs flex items-center gap-1.5 active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start Lab</span>
                </button>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
