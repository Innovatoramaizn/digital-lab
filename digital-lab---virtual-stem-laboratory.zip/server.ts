/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import http from 'http';
import path from 'path';
import dotenv from 'dotenv';
import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize GoogleGenAI SDK with server-side API Key and telemetry header
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Endpoint: Audio Transcription using model gemini-3.5-transcribe
app.post('/api/transcribe', async (req, res) => {
  try {
    const { audioBase64, mimeType } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: 'Missing audioBase64 payload' });
    }

    if (!apiKey) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please verify environment secrets.',
      });
    }

    const audioPart = {
      inlineData: {
        mimeType: mimeType || 'audio/webm',
        data: audioBase64,
      },
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [
          audioPart,
          { text: 'Transcribe this student speech or question clearly and accurately.' },
        ],
      },
    });

    const transcript = response.text || '';
    return res.json({ transcript });
  } catch (error: any) {
    console.error('Transcription error:', error);
    return res.status(500).json({
      error: error?.message || 'Failed to transcribe audio with gemini-3.5-transcribe',
    });
  }
});

// Endpoint: Science Lab AI Tutor Chat using gemini-3.8-flash
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { prompt, language = 'en', context } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    let dialectInstruction = 'Respond in clear, encouraging academic English suitable for high school and university students.';
    if (language === 'pcm') {
      dialectInstruction = 'Respond in natural, expressive Nigerian Pidgin English as a warm and encouraging lab instructor.';
    } else if (language === 'yo') {
      dialectInstruction = 'Respond in clear Yorùbá with proper diacritics and tone marks (ẹ, ọ, ṣ, à, é), accompanied by concise English translations for technical chemistry terms.';
    } else if (language === 'ha') {
      dialectInstruction = 'Respond in clear Hausa with standard orthography (ɓ, ɗ, ƙ), accompanied by concise English translations for technical chemistry terms.';
    }

    const systemInstruction = `You are LabBot, an expert virtual science laboratory tutor for West African examinations (WAEC, NECO, JAMB) and 100-level university practicals.
You understand volumetric analysis (titrations), error mitigation, parallax avoidance, concordance rules (within ±0.10 cm³), and laboratory techniques.
${dialectInstruction}
Current lab context: ${context ? JSON.stringify(context) : 'Acid-Base Titration (0.100 M HCl vs NaOH with Phenolphthalein)'}.
Keep explanations concise, friendly, and pedagogically clear.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return res.json({ text: response.text || '' });
  } catch (error: any) {
    console.error('Chat error:', error);
    return res.status(500).json({ error: error?.message || 'Chat generation failed' });
  }
});

// Setup WebSocket server for Real-Time Voice Conversations using gemini-3.8-live (Live API)
const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', (request, socket, head) => {
  const pathname = request.url ? new URL(request.url, `http://${request.headers.host}`).pathname : '';
  if (pathname === '/live' || pathname === '/api/live') {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

wss.on('connection', async (clientWs: WebSocket) => {
  console.log('Client connected to Live Voice API WebSocket');

  if (!apiKey) {
    clientWs.send(JSON.stringify({ error: 'GEMINI_API_KEY is not set on the server' }));
    clientWs.close();
    return;
  }

  let session: any = null;

  try {
    session = await ai.live.connect({
      model: 'gemini-3.8-live',
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
        },
        systemInstruction: `You are LabBot, a helpful real-time voice tutor for students conducting science laboratory experiments (WAEC, NECO, JAMB, and University 100L).
You assist with volumetric titration (HCl vs NaOH), reading the meniscus, spotting the faint pink endpoint, and calculating concentrations.
Respond via voice naturally, concisely, and warmly. You understand Nigerian contexts and dialect queries.`,
      },
      callbacks: {
        onmessage: (message: LiveServerMessage) => {
          // Model audio turn
          const parts = message.serverContent?.modelTurn?.parts;
          if (parts && parts.length > 0) {
            for (const part of parts) {
              if (part.inlineData?.data) {
                clientWs.send(JSON.stringify({ audio: part.inlineData.data }));
              }
              if (part.text) {
                clientWs.send(JSON.stringify({ text: part.text }));
              }
            }
          }
          if (message.serverContent?.interrupted) {
            clientWs.send(JSON.stringify({ interrupted: true }));
          }
        },
      },
    });

    clientWs.on('message', (data: Buffer | string) => {
      try {
        const parsed = JSON.parse(data.toString());
        if (parsed.audio) {
          // Stream raw 16kHz PCM audio to Gemini Live
          session.sendRealtimeInput({
            audio: { data: parsed.audio, mimeType: 'audio/pcm;rate=16000' },
          });
        }
        if (parsed.text) {
          session.sendRealtimeInput({
            text: parsed.text,
          });
        }
      } catch (err) {
        console.warn('Error processing client message:', err);
      }
    });

    clientWs.on('close', () => {
      console.log('Client disconnected from Live API');
      try {
        if (session && typeof session.close === 'function') {
          session.close();
        }
      } catch {
        // ignore
      }
    });

    clientWs.on('error', (err) => {
      console.error('WebSocket client error:', err);
    });
  } catch (err: any) {
    console.error('Failed to initialize gemini-3.8-live session:', err);
    clientWs.send(JSON.stringify({ error: err?.message || 'Failed to start Live session' }));
    clientWs.close();
  }
});

// Mount Vite middleware in development or serve static in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, port: PORT, host: '0.0.0.0' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Digital Lab server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
